'use strict';
// MONUMENTOS: monumentos famosos dibujados a color, FIJOS en su sitio real del mapa (mismas coordenadas para todos los jugadores).
//  - Se pintan dentro del mapa como capas de símbolos de MapLibre (no como HTML encima), para que no parpadeen.
//  - Cada monumento es un dibujo SVG (visto de frente) con la base clavada en su latitud/longitud: Sagrada Família en Barcelona,
//    Torre Eiffel en París, Coliseo en Roma…  No se mueven ni salen al azar.
//  - Se ven con zoom >= 12 (vista de ciudad). Con zoom lejos mantienen un tamaño mínimo legible y al acercarse crecen con el mapa.
//  - El nombre aparece debajo con zoom >= 14,5. Al tocar un monumento sale una ficha con su nombre y lugar (y un botón "Ir" para acercarse).
//  - Botón 🏛️ del menú para ocultarlos / mostrarlos (se recuerda en el móvil).
//  - Para añadir uno nuevo: añade su dibujo a ART y una línea a LIST (id, nombre, lugar, lat, lng, ancho en metros, tamaño del dibujo).
(function () {
  if (typeof map === 'undefined' || !map || !map.gl) return;
  const KEY = 'monumentsOn', MIN_Z = 12, LABEL_Z = 14.5, MIN_H = 38, MAX_W = 900;
  const btn = document.getElementById('mon-btn');
  let on = true;
  try { const s = localStorage.getItem(KEY); if (s !== null) on = s === '1'; } catch (e) {}

  // ---------- Ayudas para dibujar ----------
  const f = n => Math.round(n * 10) / 10;
  const rep = (n, fn) => { let s = ''; for (let i = 0; i < n; i++) s += fn(i); return s; };
  const R = (x, y, w, h, fill, x2 = '') => `<rect x="${f(x)}" y="${f(y)}" width="${f(w)}" height="${f(h)}" fill="${fill}" ${x2}/>`;
  const P = (pts, fill, x2 = '') => `<polygon points="${pts}" fill="${fill}" ${x2}/>`;
  const C = (x, y, r, fill, x2 = '') => `<circle cx="${f(x)}" cy="${f(y)}" r="${f(r)}" fill="${fill}" ${x2}/>`;
  const E = (x, y, rx, ry, fill, x2 = '') => `<ellipse cx="${f(x)}" cy="${f(y)}" rx="${f(rx)}" ry="${f(ry)}" fill="${fill}" ${x2}/>`;
  const D = (d, fill, x2 = '') => `<path d="${d}" fill="${fill}" ${x2}/>`;
  const Ln = (x1, y1, x2, y2, stroke, w = 1, x3 = '') => `<line x1="${f(x1)}" y1="${f(y1)}" x2="${f(x2)}" y2="${f(y2)}" stroke="${stroke}" stroke-width="${w}" ${x3}/>`;
  // Arco de medio punto: esquina izquierda x, suelo yb, ancho w, alto total h
  const arch = (x, yb, w, h, fill) => D(`M${f(x)} ${f(yb)}V${f(yb - h + w / 2)}a${f(w / 2)} ${f(w / 2)} 0 0 1 ${f(w)} 0V${f(yb)}Z`, fill);
  // Cúpula cebolla: centro x, base y, radio r
  const onionD = (x, y, r) => `M${f(x - r)} ${f(y)}Q${f(x - r * 1.15)} ${f(y - r * .9)} ${f(x)} ${f(y - r * 1.9)}Q${f(x + r * 1.15)} ${f(y - r * .9)} ${f(x + r)} ${f(y)}Z`;
  const onion = (x, y, r, fill, x2 = '') => D(onionD(x, y, r), fill, x2);

  // ---------- Dibujos (cada uno en su viewBox; el suelo está en la parte de abajo) ----------
  const ART = {
    sagrada() {
      const st = '#e8d3a6', sh = '#c9a974', dk = '#6f5a3c', tips = ['#e8533c', '#f2a33a', '#7bb661', '#3fa7d6'];
      const tower = (x, w, top, base, tip) =>
        D(`M${x - w / 2} ${base}L${x - w / 2 + 1} ${top + 14}Q${x - w / 2 + 1} ${top + 3} ${x} ${top + 2}Q${x + w / 2 - 1} ${top + 3} ${x + w / 2 - 1} ${top + 14}L${x + w / 2} ${base}Z`, st) +
        D(`M${x} ${top + 2}Q${x + w / 2 - 1} ${top + 3} ${x + w / 2 - 1} ${top + 14}L${x + w / 2} ${base}L${x} ${base}Z`, sh, 'opacity=".5"') +
        rep(Math.floor((base - top - 14) / 8), i => E(x, top + 18 + i * 8, w * .13, 2.4, dk)) +
        D(`M${x - w * .36} ${top + 7}Q${x} ${top - 9} ${x + w * .36} ${top + 7}Z`, tip) + C(x, top - 3, 1.5, '#ffe27a');
      let s = tower(50, 13, 16, 88, '#f2a33a');
      s += D('M50 0L51.6 4.6L56.5 4.8L52.6 8L54 12.8L50 10L46 12.8L47.4 8L43.5 4.8L48.4 4.6Z', '#ffd54a');
      [[21, 36], [36, 28], [64, 28], [79, 36]].forEach(([x, top], i) => { s += tower(x, 12, top, 92, tips[i]); });
      s += R(8, 84, 84, 32, st) + R(50, 84, 42, 32, sh, 'opacity=".28"') + R(8, 82, 84, 3, sh);
      s += arch(40, 116, 20, 30, dk) + arch(17, 116, 14, 20, dk) + arch(69, 116, 14, 20, dk);
      s += rep(9, i => C(14 + i * 9, 92, 1.7, tips[i % 4])) + rep(9, i => C(14 + i * 9, 100, 1.7, tips[(i + 2) % 4]));
      return s;
    },
    alhambra() {
      const w = '#d39a62', sh = '#b27a48', dk = '#6f4528', roof = '#a8452f';
      const cren = (x, y, n, step, cw) => rep(n, i => R(x + i * step, y, cw, 3.2, w));
      let s = R(0, 68, 100, 12, '#86b86a');
      s += R(0, 46, 100, 24, w) + R(0, 46, 100, 24, sh, 'opacity=".12"') + cren(1, 42.8, 12, 8.4, 5);
      s += R(5, 16, 20, 56, w) + R(15, 16, 10, 56, sh, 'opacity=".35"') + cren(5, 12.8, 4, 5.4, 3.4);
      s += arch(12, 36, 6, 12, dk) + R(9, 44, 2, 8, dk) + R(19, 44, 2, 8, dk) + R(14, 4, 1.1, 9, '#5b4a3a') + P('15,4 22,6.5 15,9', '#d33a2c');
      s += R(38, 26, 24, 46, w) + R(50, 26, 12, 46, sh, 'opacity=".35"') + cren(38, 22.8, 5, 5.1, 3.2) + R(38, 38, 24, 3, '#3aa6a0');
      s += arch(42, 36, 5, 10, dk) + arch(53, 36, 5, 10, dk) + arch(42, 58, 5, 10, dk) + arch(53, 58, 5, 10, dk);
      s += P('62,46 68,36 96,36 100,46', roof) + D('M74 36Q80 21 86 36Z', '#3aa6a0') + C(80, 22.5, 1.1, '#ffd54a');
      s += rep(4, i => arch(68 + i * 7.5, 70, 4.4, 10, dk));
      s += E(32, 58, 3.4, 12, '#2f6b3a') + E(30, 62, 2.6, 8, '#3d8048') + E(93, 60, 3.2, 10, '#2f6b3a') + E(50, 74, 48, 4, '#86b86a');
      return s;
    },
    giralda() {
      const o = '#dba96e', sh = '#b9854f', lt = '#efcb94', dk = '#5f4326', st = '#cfc5ab';
      let s = R(0, 90, 70, 20, st) + R(0, 90, 70, 3, '#b3a98e') + rep(6, i => arch(4 + i * 11, 110, 5, 11, '#7b715a'));
      s += D('M2 90V82h5V90ZM13 90V78h5V90ZM51 90V80h5V90ZM62 90V76h5V90Z', '#a89e84');
      s += R(20, 34, 22, 58, o) + R(31, 34, 11, 58, sh, 'opacity=".35"');
      s += rep(6, i => P(`26,${46 + i * 7.5} 29,${42.5 + i * 7.5} 32,${46 + i * 7.5} 29,${49.5 + i * 7.5}`, lt, 'opacity=".8"') +
        P(`34,${46 + i * 7.5} 37,${42.5 + i * 7.5} 40,${46 + i * 7.5} 37,${49.5 + i * 7.5}`, lt, 'opacity=".8"'));
      s += arch(28, 88, 6, 14, dk) + R(20, 32, 22, 3, sh);
      s += R(22, 20, 18, 14, '#ead7a6') + arch(24, 34, 5, 11, dk) + arch(33, 34, 5, 11, dk) + R(20, 18, 22, 3, sh);
      s += D('M22 20Q31 8 40 20Z', '#bd8f55') + R(28.5, 7, 5, 7, '#d9c08a') + D('M28 7Q31 1 34 7Z', '#a9794a');
      s += R(30.6, 0, .8, 3, '#c9a23a') + P('31.4,0.4 35,1.4 31.4,2.4', '#d9a93a');
      return s;
    },
    alcala() {
      const st = '#efe6cf', sh = '#cbbf9f', dk = '#5f5545';
      let s = R(4, 24, 92, 42, st) + R(50, 24, 46, 42, sh, 'opacity=".25"') + R(14, 12, 72, 12, '#f6eed8') + R(2, 22, 96, 4, sh) + R(12, 10, 76, 3, sh);
      s += R(40, 4, 20, 7, st) + rep(5, i => R(14 + i * 15, 3, 4, 8, '#e3d8b8')) + R(48, 0, 4, 4, sh);
      s += arch(41, 66, 18, 32, dk) + arch(23, 66, 11, 22, dk) + arch(66, 66, 11, 22, dk) + R(8, 46, 9, 20, dk) + R(83, 46, 9, 20, dk);
      s += rep(4, i => R([19, 37, 61, 79][i], 28, 2.6, 38, sh, 'opacity=".5"')) + rep(5, i => R(14 + i * 15, 15, 8, 5, '#d8cba7'));
      s += R(2, 64, 96, 5, sh);
      return s;
    },
    palacio() {
      const st = '#efe9d8', sh = '#c8bfa6', roof = '#7d8a96', win = '#6d7a87';
      let s = R(8, 12, 84, 8, roof) + R(4, 44, 92, 22, '#e6dfca') + R(4, 22, 92, 22, st) + R(2, 18, 96, 5, sh);
      s += rep(41, i => R(4 + i * 2.25, 14, .9, 4, sh));
      s += rep(9, i => arch(8 + i * 10, 40, 5, 14, win)) + rep(9, i => R(8 + i * 10, 52, 5, 10, win));
      s += R(34, 14, 32, 52, '#f6f1e2') + P('32,16 50,4 68,16', st) + P('38,15 50,8 62,15', sh, 'opacity=".6"') + C(50, 12, 2, '#d9a93a');
      s += rep(6, i => R(36 + i * 5.2, 22, 2.8, 30, sh, 'opacity=".7"')) + arch(44, 66, 12, 22, win) + R(2, 64, 96, 4, sh);
      return s;
    },
    acueducto() {
      const g = '#d9c59b', sh = '#b79e6c', dk = '#5c4a30';
      let s = R(0, 8, 100, 3, sh) + R(0, 11, 100, 15, g) + rep(19, i => arch(1.2 + i * 5.2, 26, 3.4, 12, dk));
      s += R(0, 25, 100, 3, sh) + R(0, 28, 100, 38, g) + rep(8, i => arch(3 + i * 12, 66, 8.5, 34, dk));
      s += R(0, 28, 100, 38, sh, 'opacity=".1"') + R(0, 66, 100, 4, '#8fb06b');
      return s;
    },
    mezquita() {
      const w = '#e2bb7c', sh = '#c4975a', red = '#c0392b', cr = '#f4e8cb', dk = '#4f3220';
      let s = R(26, 36, 74, 30, w) + rep(18, i => R(27 + i * 4.1, 32.5, 2.6, 4, w)) + R(26, 36, 74, 30, sh, 'opacity=".12"');
      s += rep(6, i => arch(30 + i * 11.5, 66, 9, 22, cr) + arch(31.6 + i * 11.5, 66, 5.8, 19, red) + arch(33.2 + i * 11.5, 66, 2.6, 15, dk));
      s += R(4, 12, 20, 54, '#ebc98f') + R(14, 12, 10, 54, sh, 'opacity=".3"') + R(4, 28, 20, 2.5, sh) + R(4, 50, 20, 2.5, sh);
      s += arch(8, 28, 5, 12, dk) + arch(15, 28, 5, 12, dk) + R(11.6, 36, 4, 8, dk) + R(11.6, 56, 4, 8, dk);
      s += P('3,12 14,1 25,12', '#a65c3a') + C(14, 1, 1.2, '#ffd54a');
      s += C(33, 64, 3.2, '#4c9a4a') + C(95, 64, 3.2, '#4c9a4a') + R(0, 66, 100, 4, '#d9c8a0');
      return s;
    },
    hercules() {
      const g = '#bdb5a2', sh = '#8f8773', dk = '#4d473a';
      let s = R(0, 100, 50, 10, '#4aa3d6') + P('2,100 12,92 38,92 48,100', '#7c8f58');
      s += R(10, 62, 30, 32, g) + R(25, 62, 15, 32, sh, 'opacity=".35"') + arch(21, 94, 8, 14, dk) + R(10, 60, 30, 3, sh);
      s += R(14, 40, 22, 22, '#c8c0ad') + R(25, 40, 11, 22, sh, 'opacity=".3"') + rep(2, i => R(18 + i * 8, 46, 3, 8, dk)) + R(13, 38, 24, 3, sh);
      s += R(17, 24, 16, 16, '#d3ccba') + R(25, 24, 8, 16, sh, 'opacity=".3"') + R(21.5, 28, 7, 8, dk) + R(16, 22, 18, 3, sh);
      s += R(19, 10, 12, 13, '#ddd6c4') + R(22, 13, 6, 7, '#ffd54a') + D('M17 10Q25 1 33 10Z', '#6b7c8c');
      s += rep(3, i => Ln(10, 68 + i * 8, 40, 74 + i * 8, sh, .7, 'opacity=".5"'));
      return s;
    },
    penon() {
      let s = R(0, 58, 100, 12, '#4aa3d6');
      s += P('0,58 6,40 16,24 30,10 42,5 52,10 64,22 80,34 96,46 100,58', '#d2c9b3');
      s += P('0,58 6,40 16,24 30,10 42,5 40,30 30,44 20,58', '#a89f89');
      s += E(70, 44, 20, 6, '#7fa86a') + E(56, 30, 11, 4, '#8fb276') + E(84, 52, 12, 4, '#6f9a5c');
      s += E(40, 6, 14, 4.2, '#fff', 'opacity=".9"') + E(54, 3, 12, 3.4, '#fff', 'opacity=".9"') + E(28, 8, 9, 3, '#fff', 'opacity=".85"');
      s += rep(6, i => R(70 + i * 5, 54, 4, 4, ['#f0c987', '#e9a88f', '#f4e3b0', '#b8d4e8', '#f0c987', '#e9a88f'][i]));
      return s;
    },
    santiago() {
      const st = '#dcd0b0', sh = '#b9a97d', dk = '#6a5a3a', gold = '#d9a93a';
      const tower = x => R(x, 22, 20, 78, st) + R(x + 10, 22, 10, 78, sh, 'opacity=".3"') + R(x + 1, 14, 18, 9, '#e6dcc0') + arch(x + 4, 22, 4, 10, dk) + arch(x + 12, 22, 4, 10, dk) +
        P(`${x + 2},14 ${x + 10},2 ${x + 18},14`, '#b8b08e') + R(x + 9.6, 0, .9, 4, gold) + C(x + 10, 6, 1.3, gold) + R(x, 20, 20, 3, sh);
      let s = tower(6) + tower(74) + R(26, 40, 48, 60, st) + R(50, 40, 24, 60, sh, 'opacity=".22"');
      s += P('28,40 50,20 72,40', '#e6dcc0') + P('36,39 50,26 64,39', sh, 'opacity=".5"') + C(50, 33, 2.4, gold) + R(49.4, 20, 1.2, 6, gold);
      s += arch(41, 64, 18, 26, dk) + arch(31, 98, 7, 16, dk) + arch(62, 98, 7, 16, dk) + R(36, 46, 28, 2, sh);
      s += R(12, 90, 76, 10, sh, 'opacity=".5"') + rep(7, i => R(14 + i * 10.5, 93, 8, 1.4, '#e6dcc0'));
      return s;
    },
    artes() {
      let s = R(0, 48, 100, 22, '#5bb6d9') + rep(5, i => Ln(8 + i * 18, 54 + (i % 2) * 6, 22 + i * 18, 54 + (i % 2) * 6, '#fff', .8, 'opacity=".5"'));
      s += D('M8 48Q50 -8 92 48Z', '#f4f6f8') + D('M50 4Q92 18 92 48L50 48Z', '#d5dde5', 'opacity=".6"');
      s += E(50, 34, 28, 14, '#c3d6e2') + C(50, 34, 11, '#33495e') + C(46, 30, 3.6, '#fff', 'opacity=".6"');
      s += D('M8 48Q50 100 92 48Z', '#f4f6f8', 'opacity=".28"') + R(6, 47, 88, 2.4, '#e7ecf0');
      return s;
    },
    guggenheim() {
      let s = R(0, 56, 100, 14, '#5bb0d6');
      s += D('M4 58Q10 32 34 28Q50 14 70 24Q94 26 96 58Z', '#c4cbd4') + D('M60 26Q70 2 86 24Z', '#d8dee5');
      s += D('M4 58Q10 38 28 34Q18 46 20 58Z', '#a8b1bc') + D('M50 20Q80 20 96 58L70 58Q72 34 50 20Z', '#aeb7c2');
      s += P('42,58 48,20 62,20 66,58', '#9fd0e6') + Ln(48, 20, 42, 58, '#fff', .8, 'opacity=".7"') + Ln(55, 20, 54, 58, '#fff', .6, 'opacity=".5"');
      s += D('M30 32Q50 22 68 28', 'none', 'stroke="#fff" stroke-width="1" opacity=".7"');
      s += E(18, 60, 11, 2.2, '#8a6a4a') + R(9, 46, 18, 14, '#46a84e') + C(26, 44, 6.5, '#46a84e') + E(21, 42, 3, 5, '#2f7d3a');
      s += rep(9, i => C(11 + (i % 3) * 6 + (i % 2) * 2, 49 + Math.floor(i / 3) * 4, 1.6, ['#ff5a7a', '#ffd23f', '#ff9f43', '#b05cf0', '#fff'][i % 5]));
      return s;
    },
    eiffel(id) {
      const br = '#8c6b46', dk = '#5a4330', gold = '#d6b06a';
      let s = `<clipPath id="${id}c"><path d="M4 106Q22 72 25 56Q27 34 29 20L30 4L31 20Q33 34 35 56Q38 72 56 106L44 106Q42 90 30 88Q18 90 16 106Z"/></clipPath>`;
      s += D('M4 106Q22 72 25 56Q27 34 29 20L30 4L31 20Q33 34 35 56Q38 72 56 106L44 106Q42 90 30 88Q18 90 16 106Z', br);
      s += `<g clip-path="url(#${id}c)">` + rep(18, i => Ln(0, i * 6, 60, i * 6 + 14, gold, .55, 'opacity=".6"') + Ln(60, i * 6, 0, i * 6 + 14, gold, .55, 'opacity=".6"')) +
        R(30, 0, 30, 110, dk, 'opacity=".22"') + '</g>';
      s += R(16, 76, 28, 3.6, dk) + R(23, 48, 14, 3, dk) + R(26, 28, 8, 2.6, dk) + R(20, 74.4, 20, 2, gold);
      s += Ln(30, 4, 30, 0, '#ffd54a', 1.2) + C(30, 1, 1.2, '#ffe27a');
      return s;
    },
    coliseo() {
      const t = '#dfbb88', sh = '#bf9460', dk = '#4f3822', br = '#c9794a';
      const bound = [60, 68, 80, 100];                      // hasta dónde llega cada piso antes de la rotura
      let s = P('36,24 98,24 98,64 36,64', br) + rep(8, i => R(40 + i * 7.4, 30, 3.6, 8, '#7a3f22', 'opacity=".6"'));
      s += P('2,20 62,20 70,28 76,26 84,44 98,46 98,64 2,64', t) + P('2,20 62,20 70,28 76,26 84,44 98,46 98,64 2,64', sh, 'opacity=".14"');
      [[20, 28, 0], [28, 40, 1], [40, 52, 2], [52, 64, 3]].forEach(([y0, y1, k]) => {
        if (k === 0) s += rep(10, i => { const x = 5 + i * 6; return x + 3 < bound[0] ? R(x, 22.5, 3, 4.5, dk) : ''; });
        else s += rep(14, i => { const x = 4 + i * 6.6; return x + 4.2 <= bound[k] ? arch(x, y1 - 0.8, 4.2, y1 - y0 - 3, dk) : ''; });
        if (k) s += R(2, y0 - 0.6, Math.min(bound[k], 98) - 2, 1.3, sh);
      });
      s += R(0, 64, 100, 6, '#9bbf73');
      return s;
    },
    bigben() {
      const st = '#d8c389', sh = '#b79f62', gold = '#d9a93a', dk = '#4d3d1f';
      let s = R(8, 52, 24, 58, st) + R(20, 52, 12, 58, sh, 'opacity=".35"') + rep(3, i => arch(11 + i * 7, 104, 3.6, 22, dk)) + R(6, 50, 28, 3, sh);
      s += rep(3, i => R(12.4 + i * 7, 70, 1.6, 10, sh, 'opacity=".7"'));
      s += R(7, 24, 26, 27, st) + R(20, 24, 13, 27, sh, 'opacity=".3"') + R(5, 22, 30, 3, sh);
      s += C(20, 37, 10.4, gold) + C(20, 37, 8.8, '#fff6dc') + Ln(20, 37, 20, 30.5, dk, 1) + Ln(20, 37, 25, 39.5, dk, .8) +
        rep(12, i => { const a = i * Math.PI / 6; return Ln(20 + Math.sin(a) * 7.2, 37 - Math.cos(a) * 7.2, 20 + Math.sin(a) * 8.4, 37 - Math.cos(a) * 8.4, dk, .6); });
      s += R(10, 12, 20, 11, '#e0cc94') + arch(12, 23, 4, 9, dk) + arch(18, 23, 4, 9, dk) + arch(24, 23, 4, 9, dk) + R(9, 10, 22, 3, sh);
      s += P('9,10 20,-1 31,10', '#52705f').replace('-1', '1') + R(19.5, 0, 1, 3, gold);
      return s;
    },
    libertad() {
      const cu = '#69b9a5', cd = '#4a9684', ped = '#c8c2b3';
      let s = P('6,110 11,76 39,76 44,110', ped) + P('25,76 39,76 44,110 25,110', '#a8a291', 'opacity=".4"') + R(9, 72, 32, 5, '#b8b2a2') + rep(3, i => R(14 + i * 9, 84, 2.6, 22, '#9d9786', 'opacity=".55"'));
      s += P('15,72 17,40 33,40 36,72', cu) + P('25,40 33,40 36,72 25,72', cd, 'opacity=".5"') + rep(4, i => Ln(19 + i * 4, 44, 18 + i * 4.4, 72, cd, .8, 'opacity=".7"'));
      s += P('30,43 36,36 40,16 43,16 41,38 34,48', cu) + P('39,16 44,16 43,10 40,10', '#d8b24a') + D('M41.5 10Q39 5 41.5 0Q44 5 41.5 10Z', '#ffcf3f');
      s += R(11, 46, 8, 13, cd) + R(11, 46, 8, 2, '#8fd3c0');
      s += C(25, 33, 5.5, cu) + rep(7, i => { const a = (-150 + i * 20) * Math.PI / 180; return P(`${f(25 + Math.cos(a) * 5)},${f(33 + Math.sin(a) * 5)} ${f(25 + Math.cos(a) * 11)},${f(33 + Math.sin(a) * 11)} ${f(25 + Math.cos(a + .25) * 5)},${f(33 + Math.sin(a + .25) * 5)}`, '#7fd0bb'); });
      return s;
    },
    taj() {
      const m = '#f7f3ea', sh = '#d5dbe4', dk = '#6f7a88', gold = '#e6bd4a';
      let s = R(0, 66, 100, 14, '#6fc1d6') + D('M36 68Q50 92 64 68Z', '#fff', 'opacity=".3"') + R(0, 64, 100, 3, '#8fc06a');
      s += R(6, 56, 88, 9, '#f1ece0') + R(6, 62, 88, 3, '#d9d3c3');
      [10, 83].forEach(x => { s += R(x, 22, 6, 34, m) + R(x + 3, 22, 3, 34, sh, 'opacity=".7"') + R(x - 1, 34, 8, 1.6, sh) + R(x - 1, 46, 8, 1.6, sh) + D(`M${x - .6} 22Q${x + 3} 14 ${x + 6.6} 22Z`, m) + C(x + 3, 15, .9, gold); });
      [25, 69].forEach(x => { s += R(x, 40, 6, 17, m) + R(x - 4, 43, 5, 14, '#ece7da') + R(x + 5, 43, 5, 14, '#ece7da'); });
      s += R(30, 36, 40, 21, m) + R(50, 36, 20, 21, sh, 'opacity=".45"');
      s += D('M36 38Q33 22 50 9Q67 22 64 38Z', m) + D('M50 9Q67 22 64 38L50 38Z', sh, 'opacity=".55"') + Ln(50, 9, 50, 3, gold, 1.2) + C(50, 3.4, 1.2, gold);
      s += D('M39 36V32a3 3 0 0 1 6 0V36ZM55 36V32a3 3 0 0 1 6 0V36Z', m) + C(42, 29.6, 1, gold) + C(58, 29.6, 1, gold);
      s += R(43, 38, 14, 19, '#fff') + D('M45 57V46Q50 38 55 46V57Z', dk) + D('M43 38H57', 'none', `stroke="${sh}" stroke-width="1.2"`);
      s += E(12, 62, 3.2, 8, '#2f6b3a', 'opacity=".0"') + E(92, 76, 5, 3, '#8fc06a');
      return s;
    },
    giza() {
      let s = R(0, 56, 100, 14, '#efd49a') + E(20, 66, 26, 4, '#e8c682') + E(80, 64, 24, 4, '#e8c682');
      s += P('34,58 62,8 90,58', '#e8bf6a') + P('62,8 90,58 62,58', '#c99a45') + rep(6, i => Ln(36 + i * 3, 52 - i * 8.5, 88 - i * 3.4, 52 - i * 8.5, '#b88530', .5, 'opacity=".5"'));
      s += P('2,58 24,28 46,58', '#efc877') + P('24,28 46,58 24,58', '#d2a24e') + P('56,58 70,40 84,58', '#f3d28a') + P('70,40 84,58 70,58', '#d8ab58');
      s += E(94, 62, 3, 1.4, '#4c9a4a') + Ln(94, 62, 94, 55, '#6b4a2a', 1) + E(94, 53, 5, 2, '#4c9a4a');
      return s;
    },
    cristo() {
      const w = '#f1f4f2', sh = '#cfd6d3';
      let s = P('0,100 8,86 22,78 38,78 52,86 60,100', '#5fa35a') + P('0,100 8,88 18,92 24,100', '#4a8a48') + P('36,100 46,90 60,100', '#4a8a48');
      s += R(21, 66, 18, 14, '#cfd3d0') + R(19, 78, 22, 4, '#b9bdb9') + R(21, 66, 18, 2, '#e6e9e6');
      s += P('24,66 25,28 35,28 36,66', w) + P('30,28 35,28 36,66 30,66', sh, 'opacity=".6"');
      s += P('3,28 57,28 57,33 3,33', w) + P('3,31 57,31 57,33 3,33', sh, 'opacity=".6"') + E(3, 30.5, 2.4, 3.4, w) + E(57, 30.5, 2.4, 3.4, w);
      s += C(30, 22, 4.4, w) + R(28.6, 25, 2.8, 4, w) + D('M26 21Q30 15 34 21', 'none', `stroke="${sh}" stroke-width=".8"`);
      return s;
    },
    pisa() {
      let s = R(0, 92, 50, 8, '#8fc06a') + P('30,95 52,95 48,98 28,98', '#6f9a5c', 'opacity=".5"');
      s += '<g transform="rotate(4 25 96)">';
      s += rep(7, i => { const y = 94 - (i + 1) * 10.6; return R(14, y, 22, 10.8, '#f6efdc') + R(26, y, 10, 10.8, '#e4dcc3', 'opacity=".6"') + rep(5, j => arch(15.4 + j * 4, y + 8.8, 2.4, 6, '#8c8a80')) + R(13, y, 24, 1.3, '#d9d0b8'); });
      s += R(16, 11, 18, 9, '#efe6cc') + rep(4, j => arch(17.4 + j * 4, 19, 2.6, 6, '#8c8a80')) + R(15, 8, 20, 4, '#d9d0b8') + R(17, 4, 16, 4.5, '#c9bfa5');
      s += R(13, 84, 24, 10, '#f6efdc') + R(26, 84, 11, 10, '#e4dcc3', 'opacity=".6"') + arch(22, 94, 6, 8, '#6d6a60');
      return s + '</g>';
    },
    brandeburgo() {
      const st = '#d9c8a0', sh = '#bda97a';
      let s = R(0, 62, 100, 6, sh) + R(6, 26, 88, 36, '#6e5e3e');
      s += rep(6, i => R(8 + i * 16.4, 26, 8, 36, st) + R(12 + i * 16.4, 26, 4, 36, sh, 'opacity=".55"') + R(7 + i * 16.4, 24.5, 10, 2.4, '#cdbb90'));
      s += R(4, 18, 92, 8, st) + R(4, 24, 92, 2, sh) + R(10, 10, 80, 8, '#e4d7b3') + rep(8, i => R(13 + i * 9.6, 12, 6, 4, sh, 'opacity=".7"'));
      const g = '#5aa18b';
      s += R(38, 6, 24, 4, g) + rep(4, i => D(`M${40 + i * 5} 6Q${40 + i * 5 + 1.6} 1.6 ${43.4 + i * 5} 3.4L${42.6 + i * 5} 6Z`, g));
      s += R(48.8, 0, 2.4, 6, g) + C(50, 1.2, 1.6, g) + Ln(55.5, 0.6, 55.5, 6, g, .8);
      return s;
    },
    sidney() {
      const w = '#fbfaf5', sh = '#e0dcd0';
      let s = R(0, 52, 100, 18, '#4fb0d8') + R(4, 46, 92, 8, '#d8c9a8') + R(4, 52, 92, 2, '#bfae88');
      const shell = (x0, x1, top, yb, dir) => {
        const d = `M${x0} ${yb}Q${x0 + (x1 - x0) * .1} ${top + 10} ${dir > 0 ? x1 : x0 + (x1 - x0) * .05} ${top}`;
        return D(`${d}Q${x0 + (x1 - x0) * .85} ${top + (yb - top) * .4} ${x1} ${yb}Z`, w) + D(`M${x0} ${yb}Q${x0 + (x1 - x0) * .1} ${top + 10} ${x1} ${top}Q${x0 + (x1 - x0) * .6} ${top + (yb - top) * .45} ${x0 + (x1 - x0) * .5} ${yb}Z`, sh, 'opacity=".55"');
      };
      s += shell(6, 36, 6, 48, 1) + shell(22, 46, 18, 48, 1) + shell(36, 54, 28, 48, 1);
      s += D('M94 48Q92 22 70 14Q76 32 72 48Z', w) + D('M80 48Q78 30 62 26Q66 38 64 48Z', w) + D('M94 48Q92 22 70 14Q80 34 84 48Z', sh, 'opacity=".5"');
      s += Ln(10, 46, 34, 8, '#d6d1c2', .5, 'opacity=".7"') + Ln(26, 46, 44, 20, '#d6d1c2', .5, 'opacity=".7"');
      return s;
    },
    sanbasilio(id) {
      const rd = '#c4472f', sh = '#9e3622', wh = '#f4ead2';
      const dome = (n, x, y, r, a, b, kind) => {
        const cid = `${id}d${n}`;
        let t = R(x - r * .55, y, r * 1.1, r * .8, rd) + onion(x, y, r, a) + `<clipPath id="${cid}"><path d="${onionD(x, y, r)}"/></clipPath><g clip-path="url(#${cid})">`;
        if (kind === 0) t += rep(6, i => Ln(x - r * 1.4 + i * r * .55, y, x - r * .4 + i * r * .55, y - r * 2, b, 1.3, 'opacity=".9"'));
        else if (kind === 1) t += rep(6, i => C(x - r * .7 + (i % 3) * r * .7, y - r * (.55 + Math.floor(i / 3) * .6), 1.1, b));
        else t += rep(4, i => D(`M${f(x - r)} ${f(y - 2 - i * r * .5)}Q${f(x)} ${f(y - 5 - i * r * .5)} ${f(x + r)} ${f(y - 2 - i * r * .5)}`, 'none', `stroke="${b}" stroke-width="1.3"`));
        return t + '</g>' + Ln(x, y - r * 1.9, x, y - r * 2.4, '#d9a93a', 1) + C(x, y - r * 2.5, .9, '#d9a93a');
      };
      let s = R(2, 66, 66, 34, rd) + R(36, 66, 32, 34, sh, 'opacity=".25"') + R(2, 64, 66, 3, wh) + rep(6, i => R(8 + i * 10, 76, 5, 12, '#6e2415') + R(8 + i * 10, 76, 5, 2, wh)) + R(2, 96, 66, 4, wh, 'opacity=".5"');
      s += R(26, 34, 18, 32, rd) + R(35, 34, 9, 32, sh, 'opacity=".25"') + P('24,36 35,8 46,36', '#d94f36') + P('35,8 46,36 35,36', sh, 'opacity=".3"') + rep(3, i => R(28 + i * 5.4, 44, 2.6, 8, wh)) + Ln(24, 36, 46, 36, wh, 1.6);
      s += onion(35, 9, 3.4, '#2e9e57') + Ln(35, 2.6, 35, 1, '#d9a93a', .8);
      s += dome(0, 12, 62, 8, '#2e9e57', '#f4d03f', 0) + dome(1, 58, 62, 8, '#f4ead2', '#d33a2c', 0) + dome(2, 20, 50, 6.6, '#3a74c8', '#ffd54a', 1) + dome(3, 50, 48, 6.6, '#f4d03f', '#2e9e57', 2);
      return s;
    },
    partenon() {
      const mb = '#efdfb5', sh = '#e0cc99';
      let s = P('0,70 4,56 18,52 82,52 96,56 100,70', '#a8855a') + R(10, 52, 80, 3, '#8fb06b', 'opacity=".7"');
      s += R(8, 24, 84, 26, '#7e6c4a') + R(8, 50, 84, 4, sh) + R(6, 53, 88, 3, '#d9c690');
      s += rep(8, i => R(11 + i * 10.4, 24, 6, 26, mb) + R(14 + i * 10.4, 24, 3, 26, sh, 'opacity=".8"') + R(10 + i * 10.4, 22.4, 8, 2.2, '#e6d4a8'));
      s += R(6, 16, 88, 6.6, sh) + P('6,16 50,2 94,16', '#e8d6a9') + P('16,15 50,5.6 84,15', '#cdb88a') + rep(5, i => R(10 + i * 18, 17.6, 4, 3, '#c9b27a'));
      return s;
    },
    goldengate() {
      const o = '#d9532c', dk = '#a93a1a';
      let s = R(0, 56, 100, 14, '#4fa8d6') + P('0,56 0,45 14,49 26,56', '#7bb264') + P('100,56 100,48 88,50 76,56', '#c7b27a');
      [30, 72].forEach(x => { s += R(x - 3, 10, 2.6, 46, o) + R(x + 1, 10, 2.6, 46, dk) + rep(5, i => R(x - 3, 17 + i * 8.6, 7.6, 2, o)) + R(x - 3.6, 8, 8.8, 3, dk); });
      s += R(0, 43, 100, 3, o) + R(0, 46, 100, 1.2, dk) + R(0, 40.4, 100, .8, o);
      const cab = (xa, xb, ya, yb, cy) => { let d = ''; for (let i = 0; i <= 14; i++) { const t = i / 14, x = (1 - t) * (1 - t) * xa + 2 * (1 - t) * t * ((xa + xb) / 2) + t * t * xb, y = (1 - t) * (1 - t) * ya + 2 * (1 - t) * t * cy + t * t * yb; if (i % 1 === 0 && i > 0 && i < 14) d += Ln(x, y, x, 43, o, .5, 'opacity=".75"'); } return d; };
      s += D('M30 12Q51 38 72 12', 'none', `stroke="${o}" stroke-width="1.6"`) + D('M0 38Q15 22 30 12', 'none', `stroke="${o}" stroke-width="1.4"`) + D('M72 12Q86 22 100 38', 'none', `stroke="${o}" stroke-width="1.4"`);
      s += cab(30, 72, 12, 12, 38);
      return s;
    },
    arco() {
      const st = '#dcd2b8', sh = '#bfb293', dk = '#5c5240';
      let s = R(4, 8, 72, 82, st) + R(40, 8, 36, 82, sh, 'opacity=".3"') + R(2, 4, 76, 5, sh) + R(4, 14, 72, 7, '#cfc3a4') + rep(12, i => C(8 + i * 6, 17.5, 1.8, sh));
      s += arch(24, 90, 32, 62, dk) + R(8, 40, 13, 38, '#cfc3a4') + R(59, 40, 13, 38, '#cfc3a4') + rep(2, i => E(14.5 + i * 51, 58, 4, 9, sh, 'opacity=".7"'));
      s += R(20, 24, 40, 4, sh, 'opacity=".6"') + R(2, 88, 76, 4, sh);
      return s;
    },
    duomo() {
      const w = '#f5efe6', sh = '#d9cdbb', dk = '#6a5a4a';
      let s = rep(9, i => P(`${11 + i * 9.5},52 ${13.4 + i * 9.5},${26 + (i % 3) * 5} ${15.8 + i * 9.5},52`, '#efe7db') + C(13.4 + i * 9.5, 25 + (i % 3) * 5, 1, '#d9a93a'));
      s += R(8, 50, 84, 40, w) + R(50, 50, 42, 40, sh, 'opacity=".3"') + P('26,50 50,30 74,50', '#efe7db');
      s += P('46,32 50,4 54,32', '#f0e8dc') + P('50,4 54,32 50,32', sh, 'opacity=".5"') + C(50, 3, 1.8, '#d9a93a');
      s += rep(5, i => arch(14 + i * 16, 90, 7, 26, dk)) + rep(5, i => R(16 + i * 16, 54, 3, 12, sh, 'opacity=".8"')) + arch(44, 90, 12, 34, dk) + R(8, 88, 84, 3, sh);
      return s;
    },
    atomium() {
      const T = (x1, y1, x2, y2) => Ln(x1, y1, x2, y2, '#9aa5b1', 4.2);
      const pts = { t: [40, 12], a: [16, 32], b: [64, 32], c: [16, 74], d: [64, 74], m: [40, 53], u: [40, 94] };
      let s = [['t', 'a'], ['t', 'b'], ['a', 'b'], ['a', 'c'], ['b', 'd'], ['c', 'd'], ['m', 'a'], ['m', 'b'], ['m', 'c'], ['m', 'd'], ['u', 'c'], ['u', 'd']].map(([p, q]) => T(...pts[p], ...pts[q])).join('');
      s += Object.values(pts).map(([x, y]) => C(x, y, 9, '#c9d1da') + C(x - 3, y - 3, 3.2, '#fff', 'opacity=".7"') + C(x + 2, y + 3, 6, '#a9b3be', 'opacity=".35"')).join('');
      return s;
    },
    machu() {
      let s = P('0,60 22,28 46,60', '#5f9a58') + P('46,60 64,6 80,60', '#4f8f4a') + P('64,6 80,60 64,60', '#3f7a3e', 'opacity=".6"') + P('74,60 90,32 100,44 100,60', '#6aa55e');
      s += R(0, 56, 100, 14, '#8fc06a') + rep(5, i => R(0, 53 + i * 3.4, 100, 1.2, '#b9b39a', 'opacity=".8"') + R(0, 54.2 + i * 3.4, 100, 2.2, i % 2 ? '#9acb74' : '#86b862'));
      s += rep(6, i => R(14 + i * 11, 46 + (i % 2) * 3, 7, 5, '#c9c2ad') + P(`${13 + i * 11},46 ${17.5 + i * 11},41 ${22 + i * 11},46`, '#b59a5a'));
      return s;
    },
    chichen() {
      let s = E(14, 56, 16, 12, '#4c9a4a') + E(88, 56, 16, 12, '#3f8a42') + R(0, 56, 100, 14, '#c9d68e');
      s += rep(9, i => R(10 + i * 4, 56 - (i + 1) * 4.4, 80 - i * 8, 4.6, i % 2 ? '#c4b58f' : '#d6c9a6'));
      s += R(44, 16, 12, 40, '#e8dcb9') + rep(8, i => Ln(44, 20 + i * 4.5, 56, 20 + i * 4.5, '#b9a97d', .6)) + R(36, 8, 28, 8.5, '#d6c9a6') + R(46, 10, 8, 6.5, '#4f3d28') + R(34, 6.5, 32, 2.5, '#bfae86');
      return s;
    },
    belem() {
      const w = '#efe3c6', sh = '#cdbf9b', dk = '#5c503a';
      let s = R(0, 62, 100, 18, '#5bb0d6') + R(6, 52, 88, 12, '#eadfc0') + rep(11, i => R(8 + i * 7.6, 49, 4.4, 4, '#eadfc0')) + rep(7, i => arch(12 + i * 11.5, 64, 4.6, 9, dk));
      s += R(36, 14, 30, 40, w) + R(51, 14, 15, 40, sh, 'opacity=".3"') + rep(6, i => R(36 + i * 5.2, 10.5, 3.4, 4, w)) + R(33, 14, 36, 3, sh);
      s += rep(3, i => arch(40 + i * 9, 40, 5, 12, dk)) + rep(3, i => arch(40 + i * 9, 28, 5, 9, dk)) + R(36, 42, 30, 2, sh);
      s += rep(2, i => R(30 + i * 40, 24, 6, 28, w) + D(`M${29 + i * 40} 24Q${33 + i * 40} 14 ${37 + i * 40} 24Z`, '#d9b76a') + C(33 + i * 40, 14.6, .9, '#c9a23a'));
      return s;
    },
    burj() {
      const b = '#b9d4ea', sh = '#8fb2d0', hi = '#e4f1fb';
      let s = R(2, 110, 36, 6, '#d9d3c3');
      const tier = (x, y, w, h) => R(x, y, w, h, b) + R(x + w / 2, y, w / 2, h, sh, 'opacity=".55"') + R(x + 1, y, 1.2, h, hi, 'opacity=".7"');
      s += tier(7, 88, 26, 24) + tier(10, 68, 20, 22) + tier(13, 50, 14, 20) + tier(15.4, 34, 9.2, 17) + tier(17.4, 22, 5.2, 13) + tier(18.4, 12, 3.2, 11);
      s += R(19.3, 0, 1.4, 14, '#d7e3ee') + rep(8, i => Ln(8, 94 + i * 2.6, 32, 94 + i * 2.6, '#fff', .35, 'opacity=".5"'));
      return s;
    }
    ,
    // ---- Dibujos genéricos por tipo (los usan estadios, aeropuertos y monumentos nuevos) ----
    stadium() {
      return E(50, 52, 46, 14, '#c9ced6') + E(50, 48, 40, 10, '#8a93a0') + E(50, 50, 30, 6.5, '#3f9d4a') +
        R(30, 49, 40, 1, '#fff', 'opacity=".7"') + C(50, 50, 3, 'none', 'stroke="#fff" stroke-width=".8"') +
        D('M4 52Q4 36 50 36Q96 36 96 52L96 58Q50 70 4 58Z', '#e4e7ec') + D('M4 52Q50 62 96 52L96 58Q50 70 4 58Z', '#b9bfc9') +
        rep(6, i => R(12 + i * 14, 56, 5, 3, '#6b7482', 'opacity=".6"')) + R(48, 28, 1.2, 10, '#98a1ad') + P('49.2 28 58 31 49.2 34', '#e8533c');
    },
    airport() {
      return R(0, 56, 100, 14, '#6e7480') + rep(7, i => R(6 + i * 14, 62.5, 8, 1.4, '#fff')) +
        R(10, 40, 62, 14, '#dfe5ee') + R(10, 40, 62, 3, '#3b82c4') + rep(8, i => R(14 + i * 7.4, 46, 4.4, 4, '#7fb4e3')) +
        R(80, 22, 7, 32, '#cfd6e0') + R(76, 16, 15, 7, '#7fb4e3') + R(75, 14, 17, 2.4, '#8892a0') +
        P('30 38 36 30 40 30 38 38', '#fff') + R(32, 30, 5, 1.6, '#e8533c');
    },
    tower() {
      return P('46 100 48.6 30 51.4 30 54 100', '#9aa4b2') + P('50 30 54 100 50 100', '#7e8896', 'opacity=".5"') +
        E(50, 24, 14, 4.2, '#c9d1dc') + R(36, 19, 28, 5, '#e6ebf2') + R(49.3, 2, 1.4, 17, '#7e8896') + R(43, 60, 14, 2.2, '#c9d1dc');
    },
    dome() {
      return R(10, 66, 80, 34, '#ebdcc0') + R(10, 66, 80, 3, '#c9b48c') + rep(7, i => arch(15 + i * 10.5, 100, 6, 20, '#8b7a58')) +
        R(26, 54, 48, 14, '#e2d1b0') + D('M26 54Q26 18 50 18Q74 18 74 54Z', '#9fb8c9') + D('M50 18Q74 18 74 54H50Z', '#7c98ad', 'opacity=".55"') +
        R(49.2, 4, 1.6, 15, '#c9a23a') + C(50, 5, 2, '#e9c25a');
    },
    obelisk() {
      return R(34, 90, 32, 10, '#c4c9d1') + R(40, 84, 20, 6, '#d8dce2') + P('43 84 47.5 10 52.5 10 57 84', '#e9ecf1') +
        P('50 10 57 84 50 84', '#c3c9d3', 'opacity=".7"') + P('47.5 10 50 2 52.5 10', '#d4a53a');
    },
    castle() {
      const t = (x, h) => R(x, 100 - h, 14, h, '#cdbfa6') + P(`${x - 2} ${100 - h} ${x + 7} ${100 - h - 14} ${x + 16} ${100 - h}`, '#a94f3e') + R(x + 5, 100 - h + 8, 4, 7, '#5b4c38');
      return R(8, 62, 84, 38, '#d8cbb2') + rep(9, i => R(10 + i * 9.4, 57, 5, 5, '#d8cbb2')) + t(2, 58) + t(84, 58) + t(43, 82) + arch(41, 100, 18, 22, '#4a3d2c');
    },
    pyramid() {
      return P('8 100 50 24 92 100', '#d8b878') + P('50 24 92 100 50 100', '#b8955a') + rep(5, i => Ln(8 + i * 5.5, 100 - i * 15, 92 - i * 5.5, 100 - i * 15, '#a07f48', .6, 'opacity=".6"')) + R(44, 86, 12, 14, '#4a3a22');
    }
    ,
    port() {
      const cols = ['#d9534f', '#3b82c4', '#f0ad4e', '#5cb85c', '#8e6bbf'];
      return R(0, 54, 100, 16, '#4b9fd0') + R(0, 48, 100, 7, '#8c939d') + rep(5, i => R(5 + i * 8.5, 39, 7.5, 9, cols[i % 5])) + rep(3, i => R(9 + i * 8.5, 30, 7.5, 9, cols[(i + 2) % 5])) +
        R(72, 10, 3, 38, '#e8a33a') + R(50, 10, 42, 3, '#e8a33a') + Ln(73.5, 10, 58, 30, '#c98a22', .8) + R(56, 13, 2, 10, '#555') +
        P('46 57 98 57 91 66 52 66', '#33415c') + R(62, 49, 22, 8, '#e9edf2') + R(72, 43, 6, 6, '#e8533c');
    },
    church() {
      const tw = x => R(x, 30, 16, 70, '#d9caa9') + P(`${x - 2} 30 ${x + 8} 4 ${x + 18} 30`, '#7c8a99') + arch(x + 5, 56, 6, 14, '#5b4c38');
      return R(28, 50, 44, 50, '#e3d6bc') + P('28 50 50 32 72 50', '#a9553f') + tw(10) + tw(74) + C(50, 64, 6.5, '#7fb4e3') + arch(43, 100, 14, 24, '#4a3d2c');
    },
    lighthouse() {
      return R(34, 94, 32, 6, '#8a8f98') + P('40 94 44 24 56 24 60 94', '#f2f2f2') + P('41.3 78 58.7 78 59.2 66 40.8 66', '#d9534f') + P('42.8 54 57.2 54 56.6 42 43.4 42', '#d9534f') +
        R(41, 20, 18, 4, '#444') + R(44, 10, 12, 10, '#ffe27a') + P('42 10 50 2 58 10', '#d9534f') + R(10, 12, 30, 1.5, '#ffe27a', 'opacity=".5"') + R(60, 12, 30, 1.5, '#ffe27a', 'opacity=".5"');
    },
    bridge() {
      return R(0, 52, 100, 18, '#4b9fd0') + R(0, 46, 100, 3.5, '#8a8f98') + R(23, 12, 4, 38, '#c0392b') + R(73, 12, 4, 38, '#c0392b') +
        D('M0 44Q13 44 25 14Q38 42 50 43Q62 42 75 14Q87 44 100 44', 'none', 'stroke="#c0392b" stroke-width="1.3"') + rep(10, i => Ln(30 + i * 4, 44, 30 + i * 4, 30 + Math.abs(i - 4.5) * 2.6, '#c0392b', .5));
    }
    ,
    mountain() {
      return P('0 100 36 24 50 46 63 32 100 100', '#8a9199') + P('36 24 50 46 36 100 0 100', '#a3aab2', 'opacity=".55"') + P('36 24 29 38 36 34 43 40', '#fff') + P('63 32 56 44 63 41 68 47', '#fff') + R(0, 90, 100, 10, '#5b8f4a');
    },
    pagoda() {
      return R(14, 88, 72, 12, '#8c7a5a') + rep(4, i => R(24 + i * 4, 78 - i * 18, 52 - i * 8, 10, '#e3d6bc') + P(`${14 + i * 5} ${78 - i * 18} 50 ${62 - i * 18} ${86 - i * 5} ${78 - i * 18}`, '#a94f3e')) + R(49.4, 2, 1.2, 12, '#c9a23a');
    }
  };

  // id, nombre, lugar, lat, lng, ancho en metros del dibujo, tamaño del dibujo (viewBox)
  const LIST = [
    ['sagrada', 'Sagrada Família', 'Barcelona, España', 41.4036, 2.1744, 90, [100, 120]],
    ['alhambra', 'La Alhambra', 'Granada, España', 37.1770, -3.5890, 220, [100, 80]],
    ['giralda', 'La Giralda', 'Sevilla, España', 37.3860, -5.9930, 90, [70, 110]],
    ['alcala', 'Puerta de Alcalá', 'Madrid, España', 40.4200, -3.6888, 60, [100, 70]],
    ['palacio', 'Palacio Real', 'Madrid, España', 40.4180, -3.7143, 140, [100, 70]],
    ['acueducto', 'Acueducto de Segovia', 'Segovia, España', 40.9481, -4.1177, 260, [100, 70]],
    ['mezquita', 'Mezquita de Córdoba', 'Córdoba, España', 37.8791, -4.7794, 180, [100, 70]],
    ['hercules', 'Torre de Hércules', 'A Coruña, España', 43.3860, -8.4066, 50, [50, 110]],
    ['penon', 'Peñón de Gibraltar', 'Gibraltar', 36.1350, -5.3440, 260, [100, 70]],
    ['santiago', 'Catedral de Santiago', 'Santiago de Compostela, España', 42.8806, -8.5447, 90, [100, 100]],
    ['artes', 'Ciudad de las Artes y las Ciencias', 'Valencia, España', 39.4547, -0.3510, 150, [100, 70]],
    ['guggenheim', 'Museo Guggenheim', 'Bilbao, España', 43.2687, -2.9340, 140, [100, 70]],
    ['eiffel', 'Torre Eiffel', 'París, Francia', 48.8584, 2.2945, 80, [60, 110]],
    ['coliseo', 'Coliseo', 'Roma, Italia', 41.8902, 12.4922, 170, [100, 70]],
    ['bigben', 'Big Ben', 'Londres, Reino Unido', 51.5007, -0.1246, 40, [40, 110]],
    ['libertad', 'Estatua de la Libertad', 'Nueva York, EE. UU.', 40.6892, -74.0445, 60, [50, 110]],
    ['taj', 'Taj Mahal', 'Agra, India', 27.1751, 78.0421, 200, [100, 80]],
    ['giza', 'Pirámides de Giza', 'Giza, Egipto', 29.9792, 31.1342, 260, [100, 70]],
    ['cristo', 'Cristo Redentor', 'Río de Janeiro, Brasil', -22.9519, -43.2105, 70, [60, 100]],
    ['pisa', 'Torre de Pisa', 'Pisa, Italia', 43.7230, 10.3966, 50, [50, 100]],
    ['brandeburgo', 'Puerta de Brandeburgo', 'Berlín, Alemania', 52.5163, 13.3777, 80, [100, 70]],
    ['sidney', 'Ópera de Sídney', 'Sídney, Australia', -33.8568, 151.2153, 180, [100, 70]],
    ['sanbasilio', 'Catedral de San Basilio', 'Moscú, Rusia', 55.7525, 37.6231, 70, [70, 100]],
    ['partenon', 'Partenón', 'Atenas, Grecia', 37.9715, 23.7257, 120, [100, 70]],
    ['goldengate', 'Golden Gate', 'San Francisco, EE. UU.', 37.8199, -122.4783, 260, [100, 70]],
    ['burj', 'Burj Khalifa', 'Dubái, Emiratos Árabes', 25.1972, 55.2744, 60, [40, 120]],
    ['arco', 'Arco del Triunfo', 'París, Francia', 48.8738, 2.2950, 60, [80, 90]],
    ['duomo', 'Duomo de Milán', 'Milán, Italia', 45.4642, 9.1919, 100, [100, 90]],
    ['atomium', 'Atomium', 'Bruselas, Bélgica', 50.8949, 4.3415, 60, [80, 100]],
    ['machu', 'Machu Picchu', 'Cusco, Perú', -13.1631, -72.5450, 200, [100, 70]],
    ['chichen', 'Chichén Itzá', 'Yucatán, México', 20.6829, -88.5686, 110, [100, 70]],
    ['belem', 'Torre de Belém', 'Lisboa, Portugal', 38.6916, -9.2160, 70, [100, 80]],
    // ---- Estadios (icono genérico 'stadium') ----
    ['s-campnou', 'Camp Nou', 'Barcelona, España', 41.3809, 2.1228, 260, 'stadium'],
    ['s-bernabeu', 'Santiago Bernabéu', 'Madrid, España', 40.4531, -3.6883, 230, 'stadium'],
    ['s-metropolitano', 'Cívitas Metropolitano', 'Madrid, España', 40.4362, -3.5995, 230, 'stadium'],
    ['s-mestalla', 'Mestalla', 'Valencia, España', 39.4747, -0.3583, 190, 'stadium'],
    ['s-sanmames', 'San Mamés', 'Bilbao, España', 43.2642, -2.9495, 210, 'stadium'],
    ['s-villamarin', 'Benito Villamarín', 'Sevilla, España', 37.3565, -5.9817, 200, 'stadium'],
    ['s-pizjuan', 'Ramón Sánchez-Pizjuán', 'Sevilla, España', 37.3840, -5.9706, 200, 'stadium'],
    ['s-oldtrafford', 'Old Trafford', 'Mánchester, Reino Unido', 53.4631, -2.2913, 220, 'stadium'],
    ['s-anfield', 'Anfield', 'Liverpool, Reino Unido', 53.4308, -2.9608, 200, 'stadium'],
    ['s-wembley', 'Estadio de Wembley', 'Londres, Reino Unido', 51.5560, -0.2796, 260, 'stadium'],
    ['s-emirates', 'Emirates Stadium', 'Londres, Reino Unido', 51.5549, -0.1084, 220, 'stadium'],
    ['s-etihad', 'Etihad Stadium', 'Mánchester, Reino Unido', 53.4831, -2.2004, 230, 'stadium'],
    ['s-allianz', 'Allianz Arena', 'Múnich, Alemania', 48.2188, 11.6247, 250, 'stadium'],
    ['s-dortmund', 'Signal Iduna Park', 'Dortmund, Alemania', 51.4926, 7.4519, 230, 'stadium'],
    ['s-sansiro', 'San Siro', 'Milán, Italia', 45.4781, 9.1240, 260, 'stadium'],
    ['s-juventus', 'Allianz Stadium', 'Turín, Italia', 45.1096, 7.6412, 200, 'stadium'],
    ['s-olimpico', 'Estadio Olímpico', 'Roma, Italia', 41.9341, 12.4547, 240, 'stadium'],
    ['s-parcprinces', 'Parque de los Príncipes', 'París, Francia', 48.8414, 2.2530, 200, 'stadium'],
    ['s-stadefrance', 'Stade de France', 'Saint-Denis, Francia', 48.9245, 2.3601, 250, 'stadium'],
    ['s-luz', 'Estádio da Luz', 'Lisboa, Portugal', 38.7527, -9.1847, 220, 'stadium'],
    ['s-dragao', 'Estádio do Dragão', 'Oporto, Portugal', 41.1618, -8.5833, 210, 'stadium'],
    ['s-cruyff', 'Johan Cruyff Arena', 'Ámsterdam, Países Bajos', 52.3143, 4.9419, 210, 'stadium'],
    ['s-maracana', 'Maracanã', 'Río de Janeiro, Brasil', -22.9121, -43.2302, 260, 'stadium'],
    ['s-bombonera', 'La Bombonera', 'Buenos Aires, Argentina', -34.6356, -58.3647, 170, 'stadium'],
    ['s-monumental', 'Estadio Monumental', 'Buenos Aires, Argentina', -34.5454, -58.4498, 240, 'stadium'],
    ['s-centenario', 'Estadio Centenario', 'Montevideo, Uruguay', -34.8944, -56.1527, 200, 'stadium'],
    ['s-azteca', 'Estadio Azteca', 'Ciudad de México, México', 19.3029, -99.1505, 260, 'stadium'],
    ['s-metlife', 'MetLife Stadium', 'Nueva Jersey, EE. UU.', 40.8135, -74.0745, 250, 'stadium'],
    ['s-rosebowl', 'Rose Bowl', 'Pasadena, EE. UU.', 34.1613, -118.1676, 240, 'stadium'],
    ['s-sofi', 'SoFi Stadium', 'Los Ángeles, EE. UU.', 33.9535, -118.3392, 260, 'stadium'],
    ['s-mcg', 'Melbourne Cricket Ground', 'Melbourne, Australia', -37.8200, 144.9834, 250, 'stadium'],
    ['s-tokio', 'Estadio Nacional', 'Tokio, Japón', 35.6778, 139.7145, 240, 'stadium'],
    ['s-nido', 'Nido de Pájaro', 'Pekín, China', 39.9929, 116.3964, 260, 'stadium'],
    ['s-lusail', 'Estadio de Lusail', 'Lusail, Catar', 25.4210, 51.4900, 250, 'stadium'],
    ['s-soccercity', 'FNB Stadium', 'Johannesburgo, Sudáfrica', -26.2347, 27.9826, 240, 'stadium'],
    // ---- Aeropuertos (icono genérico 'airport') ----
    ['a-mad', 'Aeropuerto Madrid-Barajas', 'Madrid, España', 40.4936, -3.5668, 700, 'airport'],
    ['a-bcn', 'Aeropuerto de Barcelona-El Prat', 'Barcelona, España', 41.2974, 2.0833, 700, 'airport'],
    ['a-pmi', 'Aeropuerto de Palma', 'Palma, España', 39.5517, 2.7388, 600, 'airport'],
    ['a-agp', 'Aeropuerto de Málaga', 'Málaga, España', 36.6749, -4.4991, 600, 'airport'],
    ['a-lhr', 'Aeropuerto de Heathrow', 'Londres, Reino Unido', 51.4700, -0.4543, 800, 'airport'],
    ['a-cdg', 'Aeropuerto Charles de Gaulle', 'París, Francia', 49.0097, 2.5479, 800, 'airport'],
    ['a-fra', 'Aeropuerto de Fráncfort', 'Fráncfort, Alemania', 50.0379, 8.5622, 750, 'airport'],
    ['a-ams', 'Aeropuerto de Schiphol', 'Ámsterdam, Países Bajos', 52.3105, 4.7683, 750, 'airport'],
    ['a-fco', 'Aeropuerto de Fiumicino', 'Roma, Italia', 41.8003, 12.2389, 700, 'airport'],
    ['a-lis', 'Aeropuerto de Lisboa', 'Lisboa, Portugal', 38.7742, -9.1342, 600, 'airport'],
    ['a-ist', 'Aeropuerto de Estambul', 'Estambul, Turquía', 41.2753, 28.7519, 850, 'airport'],
    ['a-jfk', 'Aeropuerto JFK', 'Nueva York, EE. UU.', 40.6413, -73.7781, 800, 'airport'],
    ['a-lax', 'Aeropuerto LAX', 'Los Ángeles, EE. UU.', 33.9416, -118.4085, 800, 'airport'],
    ['a-ord', 'Aeropuerto O\'Hare', 'Chicago, EE. UU.', 41.9742, -87.9073, 850, 'airport'],
    ['a-atl', 'Aeropuerto de Atlanta', 'Atlanta, EE. UU.', 33.6407, -84.4277, 850, 'airport'],
    ['a-mex', 'Aeropuerto de Ciudad de México', 'Ciudad de México, México', 19.4361, -99.0719, 700, 'airport'],
    ['a-gru', 'Aeropuerto de Guarulhos', 'São Paulo, Brasil', -23.4356, -46.4731, 750, 'airport'],
    ['a-eze', 'Aeropuerto de Ezeiza', 'Buenos Aires, Argentina', -34.8222, -58.5358, 700, 'airport'],
    ['a-dxb', 'Aeropuerto de Dubái', 'Dubái, Emiratos Árabes', 25.2532, 55.3657, 850, 'airport'],
    ['a-sin', 'Aeropuerto de Changi', 'Singapur', 1.3644, 103.9915, 800, 'airport'],
    ['a-hnd', 'Aeropuerto de Haneda', 'Tokio, Japón', 35.5494, 139.7798, 750, 'airport'],
    ['a-hkg', 'Aeropuerto de Hong Kong', 'Hong Kong', 22.3080, 113.9185, 800, 'airport'],
    ['a-pek', 'Aeropuerto de Pekín Capital', 'Pekín, China', 40.0799, 116.6031, 850, 'airport'],
    ['a-syd', 'Aeropuerto de Sídney', 'Sídney, Australia', -33.9399, 151.1753, 700, 'airport'],
    ['a-cai', 'Aeropuerto de El Cairo', 'El Cairo, Egipto', 30.1219, 31.4056, 700, 'airport'],
    ['a-jnb', 'Aeropuerto OR Tambo', 'Johannesburgo, Sudáfrica', -26.1392, 28.2460, 700, 'airport'],
    // ---- Más monumentos (iconos genéricos por tipo) ----
    ['m-empire', 'Empire State Building', 'Nueva York, EE. UU.', 40.7484, -73.9857, 50, 'tower'],
    ['m-cntower', 'Torre CN', 'Toronto, Canadá', 43.6426, -79.3871, 50, 'tower'],
    ['m-space', 'Space Needle', 'Seattle, EE. UU.', 47.6205, -122.3493, 50, 'tower'],
    ['m-tokyotower', 'Torre de Tokio', 'Tokio, Japón', 35.6586, 139.7454, 50, 'tower'],
    ['m-petronas', 'Torres Petronas', 'Kuala Lumpur, Malasia', 3.1579, 101.7116, 70, 'tower'],
    ['m-washington', 'Monumento a Washington', 'Washington D. C., EE. UU.', 38.8895, -77.0353, 40, 'obelisk'],
    ['m-moai', 'Moáis de Ahu Tongariki', 'Isla de Pascua, Chile', -27.1256, -109.2770, 50, 'obelisk'],
    ['m-capitolio', 'Capitolio de EE. UU.', 'Washington D. C., EE. UU.', 38.8899, -77.0091, 140, 'dome'],
    ['m-sanpedro', 'Basílica de San Pedro', 'Ciudad del Vaticano', 41.9022, 12.4539, 140, 'dome'],
    ['m-santasofia', 'Santa Sofía', 'Estambul, Turquía', 41.0086, 28.9802, 120, 'dome'],
    ['m-mezquitaazul', 'Mezquita Azul', 'Estambul, Turquía', 41.0054, 28.9768, 120, 'dome'],
    ['m-zayed', 'Gran Mezquita Sheikh Zayed', 'Abu Dabi, Emiratos Árabes', 24.4128, 54.4750, 180, 'dome'],
    ['m-neuschwanstein', 'Castillo de Neuschwanstein', 'Baviera, Alemania', 47.5576, 10.7498, 120, 'castle'],
    ['m-montsaintmichel', 'Mont Saint-Michel', 'Normandía, Francia', 48.6361, -1.5115, 160, 'castle'],
    ['m-towerbridge', 'Tower Bridge', 'Londres, Reino Unido', 51.5055, -0.0754, 120, 'castle'],
    ['m-ciudadprohibida', 'Ciudad Prohibida', 'Pekín, China', 39.9163, 116.3972, 200, 'castle'],
    ['m-muralla', 'Gran Muralla (Badaling)', 'Pekín, China', 40.3587, 116.0204, 200, 'castle'],
    ['m-notredame', 'Notre-Dame', 'París, Francia', 48.8530, 2.3499, 100, 'castle'],
    ['m-louvre', 'Pirámide del Louvre', 'París, Francia', 48.8611, 2.3364, 70, 'pyramid'],
    ['m-angkor', 'Angkor Wat', 'Siem Riep, Camboya', 13.4125, 103.8670, 220, 'pyramid'],
    ['m-teotihuacan', 'Pirámide del Sol', 'Teotihuacán, México', 19.6925, -98.8438, 150, 'pyramid'],
    ['m-petra', 'El Tesoro de Petra', 'Petra, Jordania', 30.3285, 35.4444, 60, 'pyramid'],
    // ---- Ampliación: puertos, campos, iglesias, castillos, faros, puentes… ----
    ['p-bcn', 'Puerto de Barcelona', 'Barcelona, España', 41.3515, 2.163, 320, 'port'],
    ['p-vlc', 'Puerto de Valencia', 'Valencia, España', 39.4428, -0.32, 320, 'port'],
    ['p-alg', 'Puerto de Algeciras', 'Algeciras, España', 36.137, -5.439, 320, 'port'],
    ['p-bio', 'Puerto de Bilbao', 'Bilbao, España', 43.345, -3.03, 320, 'port'],
    ['p-lpa', 'Puerto de La Luz', 'Las Palmas, España', 28.14, -15.42, 320, 'port'],
    ['p-rtm', 'Puerto de Róterdam', 'Róterdam, Países Bajos', 51.949, 4.12, 320, 'port'],
    ['p-anr', 'Puerto de Amberes', 'Amberes, Bélgica', 51.275, 4.32, 320, 'port'],
    ['p-ham', 'Puerto de Hamburgo', 'Hamburgo, Alemania', 53.54, 9.969, 320, 'port'],
    ['p-mrs', 'Puerto de Marsella', 'Marsella, Francia', 43.32, 5.35, 320, 'port'],
    ['p-goa', 'Puerto de Génova', 'Génova, Italia', 44.41, 8.92, 320, 'port'],
    ['p-pir', 'Puerto del Pireo', 'Atenas, Grecia', 37.94, 23.64, 320, 'port'],
    ['p-sou', 'Puerto de Southampton', 'Southampton, Reino Unido', 50.896, -1.41, 320, 'port'],
    ['p-ewr', 'Puerto de Nueva York y Nueva Jersey', 'Nueva Jersey, EE. UU.', 40.685, -74.15, 320, 'port'],
    ['p-lax', 'Puerto de Los Ángeles', 'Los Ángeles, EE. UU.', 33.73, -118.26, 320, 'port'],
    ['p-lgb', 'Puerto de Long Beach', 'Long Beach, EE. UU.', 33.75, -118.21, 320, 'port'],
    ['p-hou', 'Puerto de Houston', 'Houston, EE. UU.', 29.73, -95.27, 320, 'port'],
    ['p-yvr', 'Puerto de Vancouver', 'Vancouver, Canadá', 49.29, -123.11, 320, 'port'],
    ['p-ssz', 'Puerto de Santos', 'Santos, Brasil', -23.97, -46.3, 320, 'port'],
    ['p-bue', 'Puerto de Buenos Aires', 'Buenos Aires, Argentina', -34.61, -58.36, 320, 'port'],
    ['p-clo', 'Puerto del Callao', 'Lima, Perú', -12.05, -77.15, 320, 'port'],
    ['p-pan', 'Canal de Panamá (Miraflores)', 'Panamá', 8.996, -79.59, 320, 'port'],
    ['p-sin', 'Puerto de Singapur', 'Singapur', 1.265, 103.847, 320, 'port'],
    ['p-sha', 'Puerto de Shanghái (Yangshan)', 'Shanghái, China', 30.62, 122.06, 320, 'port'],
    ['p-szx', 'Puerto de Yantian', 'Shenzhen, China', 22.57, 114.28, 320, 'port'],
    ['p-hkg', 'Puerto de Kwai Chung', 'Hong Kong', 22.33, 114.12, 320, 'port'],
    ['p-pus', 'Puerto de Busan', 'Busan, Corea del Sur', 35.1, 129.04, 320, 'port'],
    ['p-yok', 'Puerto de Yokohama', 'Yokohama, Japón', 35.45, 139.65, 320, 'port'],
    ['p-jea', 'Puerto de Jebel Ali', 'Dubái, Emiratos Árabes', 25.01, 55.06, 320, 'port'],
    ['p-psd', 'Puerto Said', 'Puerto Said, Egipto', 31.26, 32.31, 320, 'port'],
    ['p-dur', 'Puerto de Durban', 'Durban, Sudáfrica', -29.87, 31.02, 320, 'port'],
    ['p-syd', 'Puerto Botany', 'Sídney, Australia', -33.97, 151.21, 320, 'port'],
    ['p-cpt', 'Puerto de Ciudad del Cabo', 'Ciudad del Cabo, Sudáfrica', -33.91, 18.44, 320, 'port'],
    ['p-amb', 'Puerto de Ambarlı', 'Estambul, Turquía', 40.97, 28.69, 320, 'port'],
    ['p-nsa', 'Puerto Nhava Sheva', 'Bombay, India', 18.95, 72.95, 320, 'port'],
    ['s-stamford', 'Stamford Bridge', 'Londres, Reino Unido', 51.4817, -0.191, 220, 'stadium'],
    ['s-spurs', 'Tottenham Hotspur Stadium', 'Londres, Reino Unido', 51.6043, -0.0664, 220, 'stadium'],
    ['s-villapark', 'Villa Park', 'Birmingham, Reino Unido', 52.509, -1.8847, 220, 'stadium'],
    ['s-stjames', 'St James Park', 'Newcastle, Reino Unido', 54.9756, -1.6217, 220, 'stadium'],
    ['s-celtic', 'Celtic Park', 'Glasgow, Reino Unido', 55.8497, -4.2056, 220, 'stadium'],
    ['s-ibrox', 'Ibrox', 'Glasgow, Reino Unido', 55.8531, -4.3092, 220, 'stadium'],
    ['s-hampden', 'Hampden Park', 'Glasgow, Reino Unido', 55.8259, -4.252, 220, 'stadium'],
    ['s-riazor', 'Riazor', 'A Coruña, España', 43.3687, -8.4177, 220, 'stadium'],
    ['s-balaidos', 'Balaídos', 'Vigo, España', 42.2118, -8.7396, 220, 'stadium'],
    ['s-anoeta', 'Reale Arena (Anoeta)', 'San Sebastián, España', 43.3014, -1.9737, 220, 'stadium'],
    ['s-sadar', 'El Sadar', 'Pamplona, España', 42.7966, -1.6369, 220, 'stadium'],
    ['s-rosaleda', 'La Rosaleda', 'Málaga, España', 36.7344, -4.4264, 220, 'stadium'],
    ['s-montjuic', 'Estadi Olímpic de Montjuïc', 'Barcelona, España', 41.3646, 2.1556, 220, 'stadium'],
    ['s-cornella', 'RCDE Stadium', 'Cornellà, España', 41.3478, 2.0757, 220, 'stadium'],
    ['s-veltins', 'Veltins-Arena', 'Gelsenkirchen, Alemania', 51.5546, 7.0679, 220, 'stadium'],
    ['s-volksparkh', 'Volksparkstadion', 'Hamburgo, Alemania', 53.5871, 9.8987, 220, 'stadium'],
    ['s-olympberlin', 'Olympiastadion', 'Berlín, Alemania', 52.5147, 13.2395, 220, 'stadium'],
    ['s-maradona', 'Estadio Diego Armando Maradona', 'Nápoles, Italia', 40.828, 14.1931, 220, 'stadium'],
    ['s-ferraris', 'Luigi Ferraris', 'Génova, Italia', 44.4165, 8.9523, 220, 'stadium'],
    ['s-franchi', 'Artemio Franchi', 'Florencia, Italia', 43.7808, 11.2824, 220, 'stadium'],
    ['s-velodrome', 'Orange Vélodrome', 'Marsella, Francia', 43.2699, 5.3959, 220, 'stadium'],
    ['s-groupama', 'Groupama Stadium', 'Lyon, Francia', 45.7653, 4.9822, 220, 'stadium'],
    ['s-alvalade', 'Estádio José Alvalade', 'Lisboa, Portugal', 38.7614, -9.1608, 220, 'stadium'],
    ['s-philips', 'Philips Stadion', 'Eindhoven, Países Bajos', 51.4417, 5.4674, 220, 'stadium'],
    ['s-kuip', 'De Kuip', 'Róterdam, Países Bajos', 51.8939, 4.5232, 220, 'stadium'],
    ['s-luzhniki', 'Luzhnikí', 'Moscú, Rusia', 55.7158, 37.5535, 220, 'stadium'],
    ['s-vodafone', 'Vodafone Park', 'Estambul, Turquía', 41.0391, 28.9946, 220, 'stadium'],
    ['s-morumbi', 'Morumbi', 'São Paulo, Brasil', -23.6001, -46.72, 220, 'stadium'],
    ['s-mineirao', 'Mineirão', 'Belo Horizonte, Brasil', -19.8659, -43.971, 220, 'stadium'],
    ['s-nacionalperu', 'Estadio Nacional del Perú', 'Lima, Perú', -12.0672, -77.0337, 220, 'stadium'],
    ['s-nacionalcl', 'Estadio Nacional', 'Santiago, Chile', -33.4639, -70.6103, 220, 'stadium'],
    ['s-campin', 'El Campín', 'Bogotá, Colombia', 4.6459, -74.0782, 220, 'stadium'],
    ['s-atanasio', 'Atanasio Girardot', 'Medellín, Colombia', 6.2564, -75.5905, 220, 'stadium'],
    ['s-bbva', 'Estadio BBVA', 'Monterrey, México', 25.6692, -100.244, 220, 'stadium'],
    ['s-akron', 'Estadio Akron', 'Guadalajara, México', 20.6817, -103.4627, 220, 'stadium'],
    ['s-olimpicounam', 'Estadio Olímpico Universitario', 'Ciudad de México, México', 19.3322, -99.1923, 220, 'stadium'],
    ['s-yankee', 'Yankee Stadium', 'Nueva York, EE. UU.', 40.8296, -73.9262, 220, 'stadium'],
    ['s-fenway', 'Fenway Park', 'Boston, EE. UU.', 42.3467, -71.0972, 220, 'stadium'],
    ['s-wrigley', 'Wrigley Field', 'Chicago, EE. UU.', 41.9484, -87.6553, 220, 'stadium'],
    ['s-dodger', 'Dodger Stadium', 'Los Ángeles, EE. UU.', 34.0739, -118.24, 220, 'stadium'],
    ['s-att', 'AT&T Stadium', 'Arlington, EE. UU.', 32.7473, -97.0945, 220, 'stadium'],
    ['s-mercedes', 'Mercedes-Benz Stadium', 'Atlanta, EE. UU.', 33.7554, -84.401, 220, 'stadium'],
    ['s-msg', 'Madison Square Garden', 'Nueva York, EE. UU.', 40.7505, -73.9934, 220, 'stadium'],
    ['s-twick', 'Twickenham', 'Londres, Reino Unido', 51.4559, -0.3415, 220, 'stadium'],
    ['s-murray', 'Murrayfield', 'Edimburgo, Reino Unido', 55.9422, -3.2409, 220, 'stadium'],
    ['s-cardiff', 'Principality Stadium', 'Cardiff, Reino Unido', 51.4782, -3.1826, 220, 'stadium'],
    ['s-lords', 'Lord\'s', 'Londres, Reino Unido', 51.5294, -0.1727, 220, 'stadium'],
    ['s-edenpark', 'Eden Park', 'Auckland, Nueva Zelanda', -36.8749, 174.7449, 220, 'stadium'],
    ['s-edengardens', 'Eden Gardens', 'Calcuta, India', 22.5646, 88.3433, 220, 'stadium'],
    ['s-wankhede', 'Wankhede', 'Bombay, India', 18.9389, 72.8258, 220, 'stadium'],
    ['s-modi', 'Narendra Modi Stadium', 'Ahmedabad, India', 23.0919, 72.5975, 220, 'stadium'],
    ['s-seoul', 'Estadio del Mundial', 'Seúl, Corea del Sur', 37.5683, 126.8973, 220, 'stadium'],
    ['s-azadi', 'Azadi', 'Teherán, Irán', 35.7237, 51.2753, 220, 'stadium'],
    ['s-monza', 'Autódromo de Monza', 'Monza, Italia', 45.6156, 9.2811, 300, 'stadium'],
    ['s-silverstone', 'Silverstone', 'Reino Unido', 52.0786, -1.0169, 300, 'stadium'],
    ['s-catalunya', 'Circuit de Barcelona-Catalunya', 'Montmeló, España', 41.57, 2.2611, 300, 'stadium'],
    ['s-interlagos', 'Interlagos', 'São Paulo, Brasil', -23.7036, -46.6997, 300, 'stadium'],
    ['c-colonia', 'Catedral de Colonia', 'Colonia, Alemania', 50.9413, 6.9583, 90, 'church'],
    ['c-burgos', 'Catedral de Burgos', 'Burgos, España', 42.3407, -3.7047, 90, 'church'],
    ['c-toledo', 'Catedral de Toledo', 'Toledo, España', 39.8568, -4.0243, 90, 'church'],
    ['c-bcn', 'Catedral de Barcelona', 'Barcelona, España', 41.384, 2.1764, 80, 'church'],
    ['c-sanmarcos', 'Basílica de San Marcos', 'Venecia, Italia', 45.4345, 12.3396, 90, 'church'],
    ['c-florencia', 'Santa Maria del Fiore', 'Florencia, Italia', 43.7731, 11.256, 100, 'church'],
    ['c-stpauls', 'Catedral de San Pablo', 'Londres, Reino Unido', 51.5138, -0.0984, 90, 'church'],
    ['c-westminster', 'Abadía de Westminster', 'Londres, Reino Unido', 51.4993, -0.1273, 90, 'church'],
    ['c-sacrecoeur', 'Sacré-Cœur', 'París, Francia', 48.8867, 2.3431, 80, 'church'],
    ['c-reims', 'Catedral de Reims', 'Reims, Francia', 49.2535, 4.034, 90, 'church'],
    ['c-guadalupe', 'Basílica de Guadalupe', 'Ciudad de México, México', 19.4845, -99.117, 90, 'church'],
    ['c-stpatrick', 'Catedral de San Patricio', 'Nueva York, EE. UU.', 40.7585, -73.976, 80, 'church'],
    ['c-cristosalvador', 'Catedral de Cristo Salvador', 'Moscú, Rusia', 55.7448, 37.6054, 90, 'church'],
    ['k-escorial', 'Monasterio de El Escorial', 'San Lorenzo de El Escorial, España', 40.5892, -4.1477, 180, 'castle'],
    ['k-versalles', 'Palacio de Versalles', 'Versalles, Francia', 48.8049, 2.1204, 260, 'castle'],
    ['k-alcazarsg', 'Alcázar de Segovia', 'Segovia, España', 40.9523, -4.1317, 110, 'castle'],
    ['k-alcazaba', 'Alcazaba de Málaga', 'Málaga, España', 36.7213, -4.4157, 140, 'castle'],
    ['k-edimburgo', 'Castillo de Edimburgo', 'Edimburgo, Reino Unido', 55.9486, -3.1999, 140, 'castle'],
    ['k-torrelondres', 'Torre de Londres', 'Londres, Reino Unido', 51.5081, -0.0759, 130, 'castle'],
    ['k-buckingham', 'Palacio de Buckingham', 'Londres, Reino Unido', 51.5014, -0.1419, 150, 'castle'],
    ['k-kremlin', 'Kremlin de Moscú', 'Moscú, Rusia', 55.752, 37.6175, 200, 'castle'],
    ['k-potala', 'Palacio de Potala', 'Lhasa, China', 29.6575, 91.117, 160, 'castle'],
    ['k-fuerterojo', 'Fuerte Rojo', 'Delhi, India', 28.6562, 77.241, 200, 'castle'],
    ['k-himeji', 'Castillo de Himeji', 'Himeji, Japón', 34.8394, 134.6939, 110, 'castle'],
    ['d-templocielo', 'Templo del Cielo', 'Pekín, China', 39.8822, 116.4066, 100, 'dome'],
    ['d-panteon', 'Panteón de Agripa', 'Roma, Italia', 41.8986, 12.4769, 80, 'dome'],
    ['d-roca', 'Cúpula de la Roca', 'Jerusalén', 31.778, 35.2354, 90, 'dome'],
    ['t-pearl', 'Torre Perla Oriental', 'Shanghái, China', 31.2397, 121.4998, 50, 'tower'],
    ['t-shanghai', 'Torre de Shanghái', 'Shanghái, China', 31.2335, 121.5055, 50, 'tower'],
    ['t-burjarab', 'Burj Al Arab', 'Dubái, Emiratos Árabes', 25.1412, 55.1853, 50, 'tower'],
    ['t-skytower', 'Sky Tower', 'Auckland, Nueva Zelanda', -36.8485, 174.7622, 50, 'tower'],
    ['t-collserola', 'Torre de Collserola', 'Barcelona, España', 41.4175, 2.1138, 50, 'tower'],
    ['t-fernseh', 'Torre de Televisión', 'Berlín, Alemania', 52.5208, 13.4094, 50, 'tower'],
    ['t-oro', 'Torre del Oro', 'Sevilla, España', 37.3825, -5.9964, 40, 'tower'],
    ['o-bsas', 'Obelisco de Buenos Aires', 'Buenos Aires, Argentina', -34.6037, -58.3816, 30, 'obelisk'],
    ['o-concordia', 'Obelisco de la Concordia', 'París, Francia', 48.8656, 2.3212, 30, 'obelisk'],
    ['o-trajano', 'Columna de Trajano', 'Roma, Italia', 41.8958, 12.4842, 30, 'obelisk'],
    ['o-nelson', 'Columna de Nelson', 'Londres, Reino Unido', 51.5077, -0.128, 30, 'obelisk'],
    ['f-finisterre', 'Faro de Finisterre', 'A Coruña, España', 42.8827, -9.2726, 40, 'lighthouse'],
    ['f-vilan', 'Faro de Cabo Vilán', 'A Coruña, España', 43.1558, -9.2074, 40, 'lighthouse'],
    ['f-maspalomas', 'Faro de Maspalomas', 'Gran Canaria, España', 27.7413, -15.5859, 40, 'lighthouse'],
    ['f-chipiona', 'Faro de Chipiona', 'Cádiz, España', 36.737, -6.441, 40, 'lighthouse'],
    ['f-palos', 'Faro de Cabo de Palos', 'Murcia, España', 37.6337, -0.6959, 40, 'lighthouse'],
    ['f-cabomayor', 'Faro de Cabo Mayor', 'Santander, España', 43.4944, -3.7867, 40, 'lighthouse'],
    ['f-gata', 'Faro de Cabo de Gata', 'Almería, España', 36.7219, -2.1928, 40, 'lighthouse'],
    ['b-brooklyn', 'Puente de Brooklyn', 'Nueva York, EE. UU.', 40.7061, -73.9969, 220, 'bridge'],
    ['b-25abril', 'Puente 25 de Abril', 'Lisboa, Portugal', 38.6897, -9.1773, 220, 'bridge'],
    ['b-bizkaia', 'Puente de Bizkaia', 'Portugalete, España', 43.3234, -3.0179, 220, 'bridge'],
    ['b-rialto', 'Puente de Rialto', 'Venecia, Italia', 45.438, 12.3359, 220, 'bridge'],
    ['b-carlos', 'Puente de Carlos', 'Praga, Chequia', 50.0865, 14.4114, 220, 'bridge'],
    ['b-sidneyh', 'Puente de la Bahía de Sídney', 'Sídney, Australia', -33.8523, 151.2108, 220, 'bridge'],
    ['b-akashi', 'Puente Akashi Kaikyō', 'Kobe, Japón', 34.6167, 135.0214, 220, 'bridge'],
    ['b-ronda', 'Puente Nuevo', 'Ronda, España', 36.7413, -5.1671, 220, 'bridge'],
    ['b-mostar', 'Puente Viejo de Mostar', 'Mostar, Bosnia', 43.3375, 17.815, 220, 'bridge'],
    // ---- Ampliación 2 ----
    ['a2-vlc', 'Aeropuerto de Valencia', 'Valencia, España', 39.4893, -0.4816, 750, 'airport'],
    ['a2-svq', 'Aeropuerto de Sevilla', 'Sevilla, España', 37.418, -5.8931, 750, 'airport'],
    ['a2-bio', 'Aeropuerto de Bilbao', 'Bilbao, España', 43.3011, -2.9106, 750, 'airport'],
    ['a2-alc', 'Aeropuerto de Alicante-Elche', 'Alicante, España', 38.2822, -0.5582, 750, 'airport'],
    ['a2-tfs', 'Aeropuerto de Tenerife Sur', 'Tenerife, España', 28.0445, -16.5725, 750, 'airport'],
    ['a2-lpa', 'Aeropuerto de Gran Canaria', 'Gran Canaria, España', 27.9319, -15.3866, 750, 'airport'],
    ['a2-ibz', 'Aeropuerto de Ibiza', 'Ibiza, España', 38.8729, 1.3731, 750, 'airport'],
    ['a2-scq', 'Aeropuerto de Santiago-Rosalía de Castro', 'Santiago, España', 42.8963, -8.4151, 750, 'airport'],
    ['a2-lgw', 'Aeropuerto de Gatwick', 'Londres, Reino Unido', 51.1537, -0.1821, 750, 'airport'],
    ['a2-man', 'Aeropuerto de Mánchester', 'Mánchester, Reino Unido', 53.3537, -2.275, 750, 'airport'],
    ['a2-dub', 'Aeropuerto de Dublín', 'Dublín, Irlanda', 53.4264, -6.2499, 750, 'airport'],
    ['a2-muc', 'Aeropuerto de Múnich', 'Múnich, Alemania', 48.3538, 11.7861, 750, 'airport'],
    ['a2-zrh', 'Aeropuerto de Zúrich', 'Zúrich, Suiza', 47.4582, 8.5555, 750, 'airport'],
    ['a2-vie', 'Aeropuerto de Viena', 'Viena, Austria', 48.1103, 16.5697, 750, 'airport'],
    ['a2-cph', 'Aeropuerto de Copenhague', 'Copenhague, Dinamarca', 55.618, 12.6508, 750, 'airport'],
    ['a2-arn', 'Aeropuerto de Estocolmo-Arlanda', 'Estocolmo, Suecia', 59.6498, 17.9238, 750, 'airport'],
    ['a2-hel', 'Aeropuerto de Helsinki-Vantaa', 'Helsinki, Finlandia', 60.3172, 24.9633, 750, 'airport'],
    ['a2-ath', 'Aeropuerto de Atenas', 'Atenas, Grecia', 37.9364, 23.9445, 750, 'airport'],
    ['a2-svo', 'Aeropuerto Sheremétievo', 'Moscú, Rusia', 55.9726, 37.4146, 750, 'airport'],
    ['a2-doh', 'Aeropuerto Hamad', 'Doha, Catar', 25.2731, 51.6081, 750, 'airport'],
    ['a2-del', 'Aeropuerto de Delhi', 'Delhi, India', 28.5562, 77.1, 750, 'airport'],
    ['a2-bkk', 'Aeropuerto Suvarnabhumi', 'Bangkok, Tailandia', 13.69, 100.7501, 750, 'airport'],
    ['a2-icn', 'Aeropuerto de Incheon', 'Seúl, Corea del Sur', 37.4602, 126.4407, 750, 'airport'],
    ['a2-kul', 'Aeropuerto de Kuala Lumpur', 'Kuala Lumpur, Malasia', 2.7456, 101.7072, 750, 'airport'],
    ['a2-yyz', 'Aeropuerto Pearson', 'Toronto, Canadá', 43.6777, -79.6248, 750, 'airport'],
    ['a2-sfo', 'Aeropuerto de San Francisco', 'San Francisco, EE. UU.', 37.6213, -122.379, 750, 'airport'],
    ['a2-mia', 'Aeropuerto de Miami', 'Miami, EE. UU.', 25.7959, -80.287, 750, 'airport'],
    ['a2-dfw', 'Aeropuerto Dallas-Fort Worth', 'Dallas, EE. UU.', 32.8998, -97.0403, 750, 'airport'],
    ['a2-den', 'Aeropuerto de Denver', 'Denver, EE. UU.', 39.8561, -104.6737, 750, 'airport'],
    ['a2-bog', 'Aeropuerto El Dorado', 'Bogotá, Colombia', 4.7016, -74.1469, 750, 'airport'],
    ['a2-lim', 'Aeropuerto Jorge Chávez', 'Lima, Perú', -12.0219, -77.1143, 750, 'airport'],
    ['a2-scl', 'Aeropuerto de Santiago de Chile', 'Santiago, Chile', -33.393, -70.7858, 750, 'airport'],
    ['a2-akl', 'Aeropuerto de Auckland', 'Auckland, Nueva Zelanda', -37.0082, 174.785, 750, 'airport'],
    ['a2-nbo', 'Aeropuerto de Nairobi', 'Nairobi, Kenia', -1.3192, 36.9278, 750, 'airport'],
    ['a2-cmn', 'Aeropuerto Mohamed V', 'Casablanca, Marruecos', 33.3675, -7.5898, 750, 'airport'],
    ['a2-add', 'Aeropuerto de Adís Abeba', 'Adís Abeba, Etiopía', 8.9779, 38.7993, 750, 'airport'],
    ['p2-gioia', 'Puerto de Gioia Tauro', 'Calabria, Italia', 38.44, 15.9, 320, 'port'],
    ['p2-tanger', 'Puerto Tánger Med', 'Tánger, Marruecos', 35.89, -5.5, 320, 'port'],
    ['p2-constanta', 'Puerto de Constanza', 'Constanza, Rumanía', 44.1, 28.66, 320, 'port'],
    ['p2-gdansk', 'Puerto de Gdansk', 'Gdansk, Polonia', 54.39, 18.66, 320, 'port'],
    ['p2-felixstowe', 'Puerto de Felixstowe', 'Felixstowe, Reino Unido', 51.95, 1.3, 320, 'port'],
    ['p2-lehavre', 'Puerto de El Havre', 'El Havre, Francia', 49.48, 0.1, 320, 'port'],
    ['p2-got', 'Puerto de Gotemburgo', 'Gotemburgo, Suecia', 57.7, 11.9, 320, 'port'],
    ['p2-bremerhaven', 'Puerto de Bremerhaven', 'Bremerhaven, Alemania', 53.57, 8.52, 320, 'port'],
    ['p2-tarragona', 'Puerto de Tarragona', 'Tarragona, España', 41.09, 1.23, 320, 'port'],
    ['p2-cartagena', 'Puerto de Cartagena', 'Cartagena, España', 37.58, -0.98, 320, 'port'],
    ['p2-vigo', 'Puerto de Vigo', 'Vigo, España', 42.24, -8.74, 320, 'port'],
    ['p2-musel', 'Puerto de El Musel', 'Gijón, España', 43.57, -5.69, 320, 'port'],
    ['p2-montreal', 'Puerto de Montreal', 'Montreal, Canadá', 45.51, -73.53, 320, 'port'],
    ['p2-savannah', 'Puerto de Savannah', 'Savannah, EE. UU.', 32.13, -81.14, 320, 'port'],
    ['p2-miami', 'PortMiami', 'Miami, EE. UU.', 25.78, -80.17, 320, 'port'],
    ['p2-ctg', 'Puerto de Cartagena de Indias', 'Cartagena, Colombia', 10.4, -75.5, 320, 'port'],
    ['p2-manzanillo', 'Puerto de Manzanillo', 'Manzanillo, México', 19.05, -104.3, 320, 'port'],
    ['p2-valpo', 'Puerto de Valparaíso', 'Valparaíso, Chile', -33.04, -71.63, 320, 'port'],
    ['p2-mvd', 'Puerto de Montevideo', 'Montevideo, Uruguay', -34.9, -56.21, 320, 'port'],
    ['p2-rio', 'Puerto de Río de Janeiro', 'Río de Janeiro, Brasil', -22.89, -43.18, 320, 'port'],
    ['p2-tianjin', 'Puerto de Tianjin', 'Tianjin, China', 38.99, 117.75, 320, 'port'],
    ['p2-ningbo', 'Puerto de Ningbo-Zhoushan', 'Ningbo, China', 29.93, 121.88, 320, 'port'],
    ['p2-qingdao', 'Puerto de Qingdao', 'Qingdao, China', 36.07, 120.32, 320, 'port'],
    ['p2-kaohsiung', 'Puerto de Kaohsiung', 'Kaohsiung, Taiwán', 22.61, 120.29, 320, 'port'],
    ['p2-klang', 'Puerto Klang', 'Malasia', 3.0, 101.39, 320, 'port'],
    ['p2-colombo', 'Puerto de Colombo', 'Colombo, Sri Lanka', 6.95, 79.85, 320, 'port'],
    ['p2-priok', 'Puerto de Tanjung Priok', 'Yakarta, Indonesia', -6.1, 106.88, 320, 'port'],
    ['p2-karachi', 'Puerto de Karachi', 'Karachi, Pakistán', 24.84, 66.98, 320, 'port'],
    ['p2-mombasa', 'Puerto de Mombasa', 'Mombasa, Kenia', -4.05, 39.66, 320, 'port'],
    ['p2-alex', 'Puerto de Alejandría', 'Alejandría, Egipto', 31.19, 29.88, 320, 'port'],
    ['p2-haifa', 'Puerto de Haifa', 'Haifa, Israel', 32.82, 35.0, 320, 'port'],
    ['p2-melbourne', 'Puerto de Melbourne', 'Melbourne, Australia', -37.83, 144.91, 320, 'port'],
    ['p2-fremantle', 'Puerto de Fremantle', 'Perth, Australia', -32.05, 115.74, 320, 'port'],
    ['s2-carranza', 'Nuevo Mirandilla', 'Cádiz, España', 36.5027, -6.2733, 220, 'stadium'],
    ['s2-heliodoro', 'Heliodoro Rodríguez López', 'Tenerife, España', 28.4631, -16.2611, 220, 'stadium'],
    ['s2-grancanaria', 'Estadio de Gran Canaria', 'Las Palmas, España', 28.1003, -15.4561, 220, 'stadium'],
    ['s2-sonmoix', 'Son Moix', 'Palma, España', 39.59, 2.679, 220, 'stadium'],
    ['s2-tartiere', 'Carlos Tartiere', 'Oviedo, España', 43.3654, -5.8678, 220, 'stadium'],
    ['s2-molinon', 'El Molinón', 'Gijón, España', 43.536, -5.637, 220, 'stadium'],
    ['s2-romareda', 'La Romareda', 'Zaragoza, España', 41.6364, -0.9019, 220, 'stadium'],
    ['s2-carmenes', 'Nuevo Los Cármenes', 'Granada, España', 37.153, -3.5953, 220, 'stadium'],
    ['s2-getafe', 'Coliseum', 'Getafe, España', 40.3256, -3.7147, 220, 'stadium'],
    ['s2-vallecas', 'Estadio de Vallecas', 'Madrid, España', 40.3918, -3.659, 220, 'stadium'],
    ['s2-ceramica', 'Estadio de la Cerámica', 'Villarreal, España', 39.9441, -0.1037, 220, 'stadium'],
    ['s2-cartuja', 'Estadio de La Cartuja', 'Sevilla, España', 37.4171, -6.0033, 220, 'stadium'],
    ['s2-lotto', 'Lotto Park', 'Bruselas, Bélgica', 50.8341, 4.2983, 220, 'stadium'],
    ['s2-heysel', 'Estadio Rey Balduino', 'Bruselas, Bélgica', 50.8956, 4.334, 220, 'stadium'],
    ['s2-stjakob', 'St. Jakob-Park', 'Basilea, Suiza', 47.5416, 7.6206, 220, 'stadium'],
    ['s2-wankdorf', 'Wankdorf', 'Berna, Suiza', 46.9631, 7.4647, 220, 'stadium'],
    ['s2-happel', 'Ernst Happel', 'Viena, Austria', 48.2073, 16.42, 220, 'stadium'],
    ['s2-puskas', 'Puskás Aréna', 'Budapest, Hungría', 47.5029, 19.0955, 220, 'stadium'],
    ['s2-varsovia', 'Estadio Nacional', 'Varsovia, Polonia', 52.239, 21.0455, 220, 'stadium'],
    ['s2-maksimir', 'Maksimir', 'Zagreb, Croacia', 45.8197, 16.0174, 220, 'stadium'],
    ['s2-marakana', 'Estadio Rajko Mitić', 'Belgrado, Serbia', 44.7833, 20.465, 220, 'stadium'],
    ['s2-oaka', 'Estadio Olímpico', 'Atenas, Grecia', 38.0368, 23.7881, 220, 'stadium'],
    ['s2-parken', 'Parken', 'Copenhague, Dinamarca', 55.7027, 12.5723, 220, 'stadium'],
    ['s2-aviva', 'Aviva Stadium', 'Dublín, Irlanda', 53.3352, -6.2285, 220, 'stadium'],
    ['s2-croke', 'Croke Park', 'Dublín, Irlanda', 53.3609, -6.2512, 220, 'stadium'],
    ['s2-ataturk', 'Estadio Olímpico Atatürk', 'Estambul, Turquía', 41.0745, 28.766, 220, 'stadium'],
    ['s2-gbk', 'Gelora Bung Karno', 'Yakarta, Indonesia', -6.2186, 106.8019, 220, 'stadium'],
    ['s2-rajamangala', 'Rajamangala', 'Bangkok, Tailandia', 13.7556, 100.6224, 220, 'stadium'],
    ['s2-saitama', 'Estadio de Saitama', 'Saitama, Japón', 35.9028, 139.7186, 220, 'stadium'],
    ['s2-yokohama', 'Estadio Internacional de Yokohama', 'Yokohama, Japón', 35.51, 139.6065, 220, 'stadium'],
    ['s2-suita', 'Panasonic Stadium', 'Suita, Japón', 34.8026, 135.537, 220, 'stadium'],
    ['s2-tokyodome', 'Tokyo Dome', 'Tokio, Japón', 35.7056, 139.7519, 220, 'stadium'],
    ['s2-koshien', 'Koshien', 'Nishinomiya, Japón', 34.7213, 135.3618, 220, 'stadium'],
    ['s2-scg', 'Sydney Cricket Ground', 'Sídney, Australia', -33.8914, 151.2247, 220, 'stadium'],
    ['s2-adelaide', 'Adelaide Oval', 'Adelaida, Australia', -34.9156, 138.596, 220, 'stadium'],
    ['s2-perth', 'Optus Stadium', 'Perth, Australia', -31.9511, 115.8892, 220, 'stadium'],
    ['s2-rodlaver', 'Rod Laver Arena', 'Melbourne, Australia', -37.8219, 144.9786, 220, 'stadium'],
    ['s2-zayed', 'Zayed Sports City', 'Abu Dabi, Emiratos Árabes', 24.4165, 54.4547, 220, 'stadium'],
    ['s2-capetown', 'Cape Town Stadium', 'Ciudad del Cabo, Sudáfrica', -33.9035, 18.4112, 220, 'stadium'],
    ['s2-mabhida', 'Moses Mabhida', 'Durban, Sudáfrica', -29.829, 31.03, 220, 'stadium'],
    ['s2-independiente', 'Libertadores de América', 'Avellaneda, Argentina', -34.6703, -58.3711, 220, 'stadium'],
    ['s2-kempes', 'Mario Alberto Kempes', 'Córdoba, Argentina', -31.3667, -64.2556, 220, 'stadium'],
    ['s2-gremio', 'Arena do Grêmio', 'Porto Alegre, Brasil', -29.9742, -51.1944, 220, 'stadium'],
    ['s2-beirario', 'Beira-Rio', 'Porto Alegre, Brasil', -30.0658, -51.2358, 220, 'stadium'],
    ['s2-allianzpq', 'Allianz Parque', 'São Paulo, Brasil', -23.5275, -46.6786, 220, 'stadium'],
    ['s2-mane', 'Mané Garrincha', 'Brasilia, Brasil', -15.7835, -47.8992, 220, 'stadium'],
    ['s2-sabana', 'Estadio Nacional', 'San José, Costa Rica', 9.9367, -84.1082, 220, 'stadium'],
    ['s2-soldier', 'Soldier Field', 'Chicago, EE. UU.', 41.8623, -87.6167, 220, 'stadium'],
    ['s2-lumen', 'Lumen Field', 'Seattle, EE. UU.', 47.5952, -122.3316, 220, 'stadium'],
    ['s2-oracle', 'Oracle Park', 'San Francisco, EE. UU.', 37.7786, -122.3893, 220, 'stadium'],
    ['s2-arrowhead', 'Arrowhead Stadium', 'Kansas City, EE. UU.', 39.0489, -94.4839, 220, 'stadium'],
    ['s2-gillette', 'Gillette Stadium', 'Foxborough, EE. UU.', 42.0909, -71.2643, 220, 'stadium'],
    ['s2-hardrock', 'Hard Rock Stadium', 'Miami, EE. UU.', 25.958, -80.2389, 220, 'stadium'],
    ['s2-levis', 'Levi\'s Stadium', 'Santa Clara, EE. UU.', 37.4033, -121.9694, 220, 'stadium'],
    ['s2-lincoln', 'Lincoln Financial Field', 'Filadelfia, EE. UU.', 39.9008, -75.1675, 220, 'stadium'],
    ['s2-rogers', 'Rogers Centre', 'Toronto, Canadá', 43.6414, -79.3894, 220, 'stadium'],
    ['s2-bcplace', 'BC Place', 'Vancouver, Canadá', 49.2768, -123.1119, 220, 'stadium'],
    ['s2-olympicmtl', 'Estadio Olímpico', 'Montreal, Canadá', 45.5579, -73.5516, 220, 'stadium'],
    ['s2-indy', 'Indianapolis Motor Speedway', 'Indianápolis, EE. UU.', 39.795, -86.2347, 300, 'stadium'],
    ['s2-daytona', 'Daytona International Speedway', 'Daytona Beach, EE. UU.', 29.1852, -81.0705, 300, 'stadium'],
    ['s2-churchill', 'Churchill Downs', 'Louisville, EE. UU.', 38.2032, -85.7705, 250, 'stadium'],
    ['s2-augusta', 'Augusta National', 'Augusta, EE. UU.', 33.503, -82.0199, 250, 'stadium'],
    ['s2-standrews', 'Old Course de St Andrews', 'St Andrews, Reino Unido', 56.3431, -2.8026, 250, 'stadium'],
    ['mt-everest', 'Monte Everest', 'Nepal / Tíbet', 27.9881, 86.925, 600, 'mountain'],
    ['mt-fuji', 'Monte Fuji', 'Japón', 35.3606, 138.7274, 600, 'mountain'],
    ['mt-kili', 'Kilimanjaro', 'Tanzania', -3.0674, 37.3556, 600, 'mountain'],
    ['mt-montblanc', 'Mont Blanc', 'Francia / Italia', 45.8326, 6.8652, 600, 'mountain'],
    ['mt-matterhorn', 'Cervino (Matterhorn)', 'Suiza / Italia', 45.9763, 7.6586, 600, 'mountain'],
    ['mt-teide', 'Teide', 'Tenerife, España', 28.2724, -16.6425, 600, 'mountain'],
    ['mt-aconcagua', 'Aconcagua', 'Argentina', -32.6532, -70.0109, 600, 'mountain'],
    ['mt-uluru', 'Uluru', 'Australia', -25.3444, 131.0369, 600, 'mountain'],
    ['mt-etna', 'Etna', 'Sicilia, Italia', 37.751, 14.9934, 600, 'mountain'],
    ['mt-vesubio', 'Vesubio', 'Nápoles, Italia', 40.8219, 14.4263, 600, 'mountain'],
    ['mt-table', 'Montaña de la Mesa', 'Ciudad del Cabo, Sudáfrica', -33.9628, 18.4098, 600, 'mountain'],
    ['mt-denali', 'Denali', 'Alaska, EE. UU.', 63.0692, -151.007, 600, 'mountain'],
    ['mt-olimpo', 'Monte Olimpo', 'Grecia', 40.0853, 22.3586, 600, 'mountain'],
    ['mt-paine', 'Torres del Paine', 'Chile', -50.9423, -73.4068, 600, 'mountain'],
    ['mt-panazucar', 'Pan de Azúcar', 'Río de Janeiro, Brasil', -22.9492, -43.1545, 600, 'mountain'],
    ['mt-mulhacen', 'Mulhacén', 'Sierra Nevada, España', 37.0535, -3.3112, 600, 'mountain'],
    ['mt-montserrat', 'Montserrat', 'Barcelona, España', 41.5934, 1.8108, 600, 'mountain'],
    ['mt-ifach', 'Peñón de Ifach', 'Calpe, España', 38.6326, 0.0777, 600, 'mountain'],
    ['mt-roque', 'Roque Nublo', 'Gran Canaria, España', 27.9654, -15.6, 600, 'mountain'],
    ['mt-halfdome', 'Half Dome', 'Yosemite, EE. UU.', 37.7459, -119.5332, 600, 'mountain'],
    ['pg-sensoji', 'Templo Senso-ji', 'Tokio, Japón', 35.7148, 139.7967, 70, 'pagoda'],
    ['pg-kiyomizu', 'Templo Kiyomizu-dera', 'Kioto, Japón', 34.9949, 135.785, 80, 'pagoda'],
    ['pg-watarun', 'Wat Arun', 'Bangkok, Tailandia', 13.7437, 100.4889, 70, 'pagoda'],
    ['pg-palaciobkk', 'Gran Palacio de Bangkok', 'Bangkok, Tailandia', 13.75, 100.4913, 120, 'pagoda'],
    ['pg-prambanan', 'Prambanan', 'Yogyakarta, Indonesia', -7.752, 110.4915, 100, 'pagoda'],
    ['pg-oca', 'Pagoda de la Oca Salvaje', 'Xi\'an, China', 34.2189, 108.9594, 60, 'pagoda'],
    ['pg-tiantan', 'Gran Buda de Tian Tan', 'Hong Kong', 22.254, 113.9047, 60, 'pagoda'],
    ['pg-mahabodhi', 'Templo de Mahabodhi', 'Bodh Gaya, India', 24.6961, 84.9911, 70, 'pagoda'],
    ['pg-hawa', 'Hawa Mahal', 'Jaipur, India', 26.9239, 75.8267, 70, 'pagoda'],
    ['pg-amber', 'Fuerte de Amber', 'Jaipur, India', 26.9855, 75.8513, 160, 'pagoda'],
    ['t2-willis', 'Torre Willis', 'Chicago, EE. UU.', 41.8789, -87.6359, 50, 'tower'],
    ['t2-wtc', 'One World Trade Center', 'Nueva York, EE. UU.', 40.7127, -74.0134, 50, 'tower'],
    ['t2-gherkin', 'The Gherkin', 'Londres, Reino Unido', 51.5145, -0.0803, 50, 'tower'],
    ['t2-shard', 'The Shard', 'Londres, Reino Unido', 51.5045, -0.0865, 50, 'tower'],
    ['t2-taipei', 'Taipei 101', 'Taipéi, Taiwán', 25.034, 121.5645, 50, 'tower'],
    ['t2-lotte', 'Lotte World Tower', 'Seúl, Corea del Sur', 37.5126, 127.1026, 50, 'tower'],
    ['t2-ostankino', 'Torre Ostánkino', 'Moscú, Rusia', 55.8197, 37.6117, 50, 'tower'],
    ['t2-agbar', 'Torre Glòries', 'Barcelona, España', 41.4036, 2.1894, 50, 'tower'],
    ['t2-picasso', 'Torre Picasso', 'Madrid, España', 40.4503, -3.693, 50, 'tower'],
    ['t2-kio', 'Puerta de Europa', 'Madrid, España', 40.4659, -3.6892, 60, 'tower'],
    ['t2-gts', 'Gran Torre Santiago', 'Santiago, Chile', -33.4177, -70.6066, 50, 'tower'],
    ['t2-latino', 'Torre Latinoamericana', 'Ciudad de México, México', 19.4339, -99.1406, 50, 'tower'],
    ['t2-qutb', 'Qutb Minar', 'Delhi, India', 28.5245, 77.1855, 50, 'tower'],
    ['t2-mbs', 'Marina Bay Sands', 'Singapur', 1.2834, 103.8607, 130, 'tower'],
    ['t2-stratos', 'The Strat', 'Las Vegas, EE. UU.', 36.1475, -115.1559, 50, 'tower'],
    ['t2-merdeka', 'Merdeka 118', 'Kuala Lumpur, Malasia', 3.1417, 101.7, 50, 'tower'],
    ['o2-colon', 'Monumento a Colón', 'Barcelona, España', 41.3758, 2.1778, 30, 'obelisk'],
    ['o2-angel', 'Ángel de la Independencia', 'Ciudad de México, México', 19.427, -99.1677, 30, 'obelisk'],
    ['o2-kamakura', 'Gran Buda de Kamakura', 'Kamakura, Japón', 35.3167, 139.5358, 40, 'obelisk'],
    ['o2-leshan', 'Gran Buda de Leshan', 'Leshan, China', 29.5446, 103.7699, 40, 'obelisk'],
    ['o2-cristolima', 'Cristo del Pacífico', 'Lima, Perú', -12.1582, -77.0231, 40, 'obelisk'],
    ['o2-cristocbba', 'Cristo de la Concordia', 'Cochabamba, Bolivia', -17.3838, -66.1342, 40, 'obelisk'],
    ['o2-panecillo', 'Virgen del Panecillo', 'Quito, Ecuador', -0.229, -78.5148, 40, 'obelisk'],
    ['o2-volgogrado', 'La Madre Patria Llama', 'Volgogrado, Rusia', 48.7424, 44.537, 40, 'obelisk'],
    ['o2-kiev', 'Monumento a la Madre Patria', 'Kiev, Ucrania', 50.4266, 30.5594, 40, 'obelisk'],
    ['o2-unidad', 'Estatua de la Unidad', 'Gujarat, India', 21.838, 73.7191, 40, 'obelisk'],
    ['d2-oro', 'Templo Dorado', 'Amritsar, India', 31.62, 74.8765, 100, 'dome'],
    ['d2-akshardham', 'Akshardham', 'Delhi, India', 28.6127, 77.2773, 100, 'dome'],
    ['d2-loto', 'Templo del Loto', 'Delhi, India', 28.5535, 77.2588, 90, 'dome'],
    ['d2-reichstag', 'Reichstag', 'Berlín, Alemania', 52.5186, 13.3762, 110, 'dome'],
    ['d2-revolucion', 'Monumento a la Revolución', 'Ciudad de México, México', 19.4361, -99.1546, 80, 'dome'],
    ['d2-parlamentohu', 'Parlamento de Hungría', 'Budapest, Hungría', 47.5071, 19.0457, 200, 'dome'],
    ['d2-vittoriano', 'Monumento a Víctor Manuel II', 'Roma, Italia', 41.8946, 12.4831, 130, 'dome'],
    ['d2-shwedagon', 'Pagoda Shwedagon', 'Rangún, Myanmar', 16.7983, 96.1495, 120, 'dome'],
    ['k2-praga', 'Castillo de Praga', 'Praga, Chequia', 50.0909, 14.4009, 220, 'castle'],
    ['k2-bran', 'Castillo de Bran', 'Brașov, Rumanía', 45.515, 25.3671, 100, 'castle'],
    ['k2-toledo', 'Alcázar de Toledo', 'Toledo, España', 39.8581, -4.02, 110, 'castle'],
    ['k2-penafiel', 'Castillo de Peñafiel', 'Valladolid, España', 41.6001, -4.1208, 160, 'castle'],
    ['k2-coca', 'Castillo de Coca', 'Segovia, España', 41.2147, -4.5258, 100, 'castle'],
    ['k2-loarre', 'Castillo de Loarre', 'Huesca, España', 42.3217, -0.6105, 110, 'castle'],
    ['k2-pena', 'Palacio da Pena', 'Sintra, Portugal', 38.7876, -9.3906, 110, 'castle'],
    ['k2-alcazarsev', 'Reales Alcázares', 'Sevilla, España', 37.3831, -5.9906, 140, 'castle'],
    ['k2-aljaferia', 'Palacio de la Aljafería', 'Zaragoza, España', 41.656, -0.897, 130, 'castle'],
    ['k2-poblet', 'Monasterio de Poblet', 'Tarragona, España', 41.3811, 1.0847, 140, 'castle'],
    ['k2-gateway', 'Puerta de la India', 'Bombay, India', 18.922, 72.8347, 60, 'castle'],
    ['y2-borobudur', 'Borobudur', 'Java, Indonesia', -7.6079, 110.2038, 150, 'pyramid'],
    ['y2-karnak', 'Templo de Karnak', 'Luxor, Egipto', 25.7188, 32.6573, 180, 'pyramid'],
    ['y2-abusimbel', 'Abu Simbel', 'Asuán, Egipto', 22.3372, 31.6258, 90, 'pyramid'],
    ['y2-esfinge', 'Gran Esfinge de Giza', 'Giza, Egipto', 29.9753, 31.1376, 70, 'pyramid'],
    ['y2-transamerica', 'Pirámide Transamerica', 'San Francisco, EE. UU.', 37.7952, -122.4028, 60, 'pyramid'],
    // ---- Ampliación 3 ----
    ['z-canton', 'Torre de Cantón', 'Cantón, China', 23.1065, 113.3245, 50, 'tower'],
    ['z-pingan', 'Ping An Finance Center', 'Shenzhen, China', 22.5362, 114.0516, 50, 'tower'],
    ['z-skytree', 'Tokyo Skytree', 'Tokio, Japón', 35.7101, 139.8107, 50, 'tower'],
    ['z-clock', 'Torres del Reloj de La Meca', 'La Meca, Arabia Saudí', 21.4189, 39.826, 50, 'tower'],
    ['z-lakhta', 'Centro Lájta', 'San Petersburgo, Rusia', 59.9871, 30.1778, 50, 'tower'],
    ['z-federation', 'Torre Federación', 'Moscú, Rusia', 55.7496, 37.5373, 50, 'tower'],
    ['z-eureka', 'Eureka Tower', 'Melbourne, Australia', -37.8214, 144.9645, 50, 'tower'],
    ['z-q1', 'Q1', 'Gold Coast, Australia', -28.0063, 153.4296, 50, 'tower'],
    ['z-sydneytower', 'Sydney Tower', 'Sídney, Australia', -33.8705, 151.2089, 50, 'tower'],
    ['z-reforma', 'Torre Reforma', 'Ciudad de México, México', 19.4263, -99.1735, 50, 'tower'],
    ['z-menara', 'Menara Kuala Lumpur', 'Kuala Lumpur, Malasia', 3.1528, 101.7038, 50, 'tower'],
    ['z-jinmao', 'Torre Jin Mao', 'Shanghái, China', 31.2358, 121.5014, 50, 'tower'],
    ['z-cctv', 'Sede de CCTV', 'Pekín, China', 39.915, 116.4585, 50, 'tower'],
    ['z-chrysler', 'Edificio Chrysler', 'Nueva York, EE. UU.', 40.7516, -73.9755, 50, 'tower'],
    ['z-rockefeller', 'Rockefeller Center', 'Nueva York, EE. UU.', 40.7587, -73.9787, 50, 'tower'],
    ['z-bofa', 'Bank of America Tower', 'Nueva York, EE. UU.', 40.7557, -73.9845, 50, 'tower'],
    ['z-hancock', 'John Hancock Center', 'Chicago, EE. UU.', 41.8988, -87.6232, 50, 'tower'],
    ['z-salesforce', 'Salesforce Tower', 'San Francisco, EE. UU.', 37.7897, -122.3969, 50, 'tower'],
    ['z-comcast', 'Comcast Center', 'Filadelfia, EE. UU.', 39.9545, -75.1683, 50, 'tower'],
    ['z-fcp', 'First Canadian Place', 'Toronto, Canadá', 43.6486, -79.3816, 50, 'tower'],
    ['z-cepsa', 'Torre Cepsa', 'Madrid, España', 40.475, -3.687, 50, 'tower'],
    ['z-cristal', 'Torre de Cristal', 'Madrid, España', 40.4739, -3.6873, 50, 'tower'],
    ['z-iberdrola', 'Torre Iberdrola', 'Bilbao, España', 43.2656, -2.9391, 50, 'tower'],
    ['z-europa', 'Torre Europa', 'Madrid, España', 40.4492, -3.6934, 50, 'tower'],
    ['z-mapfre', 'Torre Mapfre', 'Barcelona, España', 41.3874, 2.2004, 50, 'tower'],
    ['z-commerz', 'Commerzbank Tower', 'Fráncfort, Alemania', 50.1103, 8.673, 50, 'tower'],
    ['z-bosco', 'Bosco Verticale', 'Milán, Italia', 45.4871, 9.1907, 50, 'tower'],
    ['z-unicredit', 'Torre Unicredit', 'Milán, Italia', 45.4833, 9.1903, 50, 'tower'],
    ['z-capitalgate', 'Capital Gate', 'Abu Dabi, Emiratos Árabes', 24.4237, 54.4388, 50, 'tower'],
    ['z-emirates', 'Emirates Towers', 'Dubái, Emiratos Árabes', 25.2177, 55.2823, 50, 'tower'],
    ['z-jeddah', 'Torre Yeda', 'Yeda, Arabia Saudí', 21.7225, 39.1537, 50, 'tower'],
    ['z-kingdom', 'Kingdom Centre', 'Riad, Arabia Saudí', 24.7114, 46.6743, 50, 'tower'],
    ['z-boc', 'Torre del Banco de China', 'Hong Kong', 22.2795, 114.1618, 50, 'tower'],
    ['z-ifc', 'International Finance Centre', 'Hong Kong', 22.2851, 114.1587, 50, 'tower'],
    ['z-l81', 'Landmark 81', 'Ciudad Ho Chi Minh, Vietnam', 10.7952, 106.7218, 50, 'tower'],
    ['z-baiyoke', 'Baiyoke Tower II', 'Bangkok, Tailandia', 13.7536, 100.5402, 50, 'tower'],
    ['z-mahanakhon', 'MahaNakhon', 'Bangkok, Tailandia', 13.7231, 100.5283, 50, 'tower'],
    ['zm-annapurna', 'Annapurna', 'Nepal', 28.5961, 83.8203, 600, 'mountain'],
    ['zm-k2', 'K2', 'Pakistán / China', 35.8825, 76.5133, 600, 'mountain'],
    ['zm-kanch', 'Kanchenjunga', 'Nepal / India', 27.7025, 88.1475, 600, 'mountain'],
    ['zm-lhotse', 'Lhotse', 'Nepal / Tíbet', 27.9617, 86.9331, 600, 'mountain'],
    ['zm-makalu', 'Makalu', 'Nepal / Tíbet', 27.8897, 87.0886, 600, 'mountain'],
    ['zm-choyu', 'Cho Oyu', 'Nepal / Tíbet', 28.0942, 86.6609, 600, 'mountain'],
    ['zm-nanga', 'Nanga Parbat', 'Pakistán', 35.2372, 74.5892, 600, 'mountain'],
    ['zm-elbrus', 'Elbrus', 'Rusia', 43.3499, 42.4453, 600, 'mountain'],
    ['zm-ventoux', 'Mont Ventoux', 'Francia', 44.1739, 5.2786, 600, 'mountain'],
    ['zm-eiger', 'Eiger', 'Suiza', 46.5775, 8.0053, 600, 'mountain'],
    ['zm-jungfrau', 'Jungfrau', 'Suiza', 46.5368, 7.9626, 600, 'mountain'],
    ['zm-zugspitze', 'Zugspitze', 'Alemania / Austria', 47.4211, 10.9853, 600, 'mountain'],
    ['zm-triglav', 'Triglav', 'Eslovenia', 46.3786, 13.8369, 600, 'mountain'],
    ['zm-rosa', 'Monte Rosa', 'Suiza / Italia', 45.9369, 7.8669, 600, 'mountain'],
    ['zm-aneto', 'Aneto', 'Huesca, España', 42.6314, 0.6564, 600, 'mountain'],
    ['zm-perdido', 'Monte Perdido', 'Huesca, España', 42.6783, 0.0328, 600, 'mountain'],
    ['zm-urriellu', 'Naranjo de Bulnes', 'Asturias, España', 43.1983, -4.8517, 600, 'mountain'],
    ['zm-pedraforca', 'Pedraforca', 'Barcelona, España', 42.2386, 1.7022, 600, 'mountain'],
    ['zm-kenya', 'Monte Kenia', 'Kenia', -0.1521, 37.3084, 600, 'mountain'],
    ['zm-cook', 'Monte Cook', 'Nueva Zelanda', -43.595, 170.1418, 600, 'mountain'],
    ['zm-kosciuszko', 'Monte Kosciuszko', 'Australia', -36.4561, 148.2639, 600, 'mountain'],
    ['zm-rainier', 'Monte Rainier', 'EE. UU.', 46.8523, -121.7603, 600, 'mountain'],
    ['zm-sthelens', 'Monte St. Helens', 'EE. UU.', 46.1914, -122.1956, 600, 'mountain'],
    ['zm-whitney', 'Monte Whitney', 'EE. UU.', 36.5786, -118.292, 600, 'mountain'],
    ['zm-hood', 'Monte Hood', 'EE. UU.', 45.3735, -121.6959, 600, 'mountain'],
    ['zm-teton', 'Grand Teton', 'EE. UU.', 43.741, -110.8024, 600, 'mountain'],
    ['zm-chimborazo', 'Chimborazo', 'Ecuador', -1.4693, -78.8175, 600, 'mountain'],
    ['zm-cotopaxi', 'Cotopaxi', 'Ecuador', -0.6838, -78.4372, 600, 'mountain'],
    ['zm-huascaran', 'Huascarán', 'Perú', -9.1219, -77.6044, 600, 'mountain'],
    ['zm-fitzroy', 'Fitz Roy', 'Argentina / Chile', -49.2711, -73.0436, 600, 'mountain'],
    ['zm-illimani', 'Illimani', 'Bolivia', -16.6392, -67.7886, 600, 'mountain'],
    ['zm-ojos', 'Ojos del Salado', 'Chile / Argentina', -27.1092, -68.5414, 600, 'mountain'],
    ['zm-orizaba', 'Pico de Orizaba', 'México', 19.03, -97.2699, 600, 'mountain'],
    ['zm-popo', 'Popocatépetl', 'México', 19.0225, -98.6278, 600, 'mountain'],
    ['zm-maunakea', 'Mauna Kea', 'Hawái, EE. UU.', 19.8207, -155.4681, 600, 'mountain'],
    ['zm-krakatoa', 'Krakatoa', 'Indonesia', -6.1021, 105.423, 600, 'mountain'],
    ['zm-mayon', 'Volcán Mayón', 'Filipinas', 13.2569, 123.6856, 600, 'mountain'],
    ['zm-kinabalu', 'Monte Kinabalu', 'Malasia', 6.075, 116.5583, 600, 'mountain'],
    ['zm-bromo', 'Monte Bromo', 'Indonesia', -7.9425, 112.953, 600, 'mountain'],
    ['zm-ararat', 'Monte Ararat', 'Turquía', 39.7018, 44.2984, 600, 'mountain'],
    ['zm-hekla', 'Hekla', 'Islandia', 63.992, -19.6656, 600, 'mountain'],
    ['zm-eyja', 'Eyjafjallajökull', 'Islandia', 63.6314, -19.6083, 600, 'mountain'],
    ['zm-stromboli', 'Stromboli', 'Italia', 38.789, 15.213, 600, 'mountain'],
    ['zs-london', 'Estadio de Londres', 'Londres, Reino Unido', 51.5387, -0.0166, 220, 'stadium'],
    ['zs-goodison', 'Goodison Park', 'Liverpool, Reino Unido', 53.4388, -2.9664, 220, 'stadium'],
    ['zs-elland', 'Elland Road', 'Leeds, Reino Unido', 53.7778, -1.5722, 220, 'stadium'],
    ['zs-bramall', 'Bramall Lane', 'Sheffield, Reino Unido', 53.3703, -1.4709, 220, 'stadium'],
    ['zs-craven', 'Craven Cottage', 'Londres, Reino Unido', 51.4749, -0.2217, 220, 'stadium'],
    ['zs-selhurst', 'Selhurst Park', 'Londres, Reino Unido', 51.3983, -0.0855, 220, 'stadium'],
    ['zs-molineux', 'Molineux', 'Wolverhampton, Reino Unido', 52.5902, -2.1306, 220, 'stadium'],
    ['zs-turfmoor', 'Turf Moor', 'Burnley, Reino Unido', 53.789, -2.2302, 220, 'stadium'],
    ['zs-carrow', 'Carrow Road', 'Norwich, Reino Unido', 52.6221, 1.3092, 220, 'stadium'],
    ['zs-louis2', 'Stade Louis II', 'Mónaco', 43.7277, 7.4154, 220, 'stadium'],
    ['zs-mauroy', 'Stade Pierre-Mauroy', 'Lille, Francia', 50.6119, 3.1305, 220, 'stadium'],
    ['zs-gerland', 'Stade de Gerland', 'Lyon, Francia', 45.7233, 4.8322, 220, 'stadium'],
    ['zs-riviera', 'Allianz Riviera', 'Niza, Francia', 43.705, 7.1925, 220, 'stadium'],
    ['zs-gewiss', 'Gewiss Stadium', 'Bérgamo, Italia', 45.7089, 9.6808, 220, 'stadium'],
    ['zs-bentegodi', 'Stadio Bentegodi', 'Verona, Italia', 45.4352, 10.9686, 220, 'stadium'],
    ['zs-bayarena', 'BayArena', 'Leverkusen, Alemania', 51.0383, 7.0022, 220, 'stadium'],
    ['zs-stuttgart', 'Mercedes-Benz Arena', 'Stuttgart, Alemania', 48.7923, 9.2319, 220, 'stadium'],
    ['zs-frankfurt', 'Deutsche Bank Park', 'Fráncfort, Alemania', 50.0686, 8.6455, 220, 'stadium'],
    ['zs-borussia', 'Borussia-Park', 'Mönchengladbach, Alemania', 51.1745, 6.3855, 220, 'stadium'],
    ['zs-leipzig', 'Red Bull Arena', 'Leipzig, Alemania', 51.3458, 12.3483, 220, 'stadium'],
    ['zs-forsterei', 'Alte Försterei', 'Berlín, Alemania', 52.4572, 13.5681, 220, 'stadium'],
    ['zs-millerntor', 'Millerntor', 'Hamburgo, Alemania', 53.5545, 9.9677, 220, 'stadium'],
    ['zs-salzburg', 'Red Bull Arena', 'Salzburgo, Austria', 47.8165, 12.9989, 220, 'stadium'],
    ['zs-martinez', 'Martínez Valero', 'Elche, España', 38.2673, -0.6633, 220, 'stadium'],
    ['zs-zorrilla', 'José Zorrilla', 'Valladolid, España', 41.6445, -4.7612, 220, 'stadium'],
    ['zs-letzigrund', 'Letzigrund', 'Zúrich, Suiza', 47.3825, 8.5039, 220, 'stadium'],
    ['zs-braga', 'Estádio Municipal de Braga', 'Braga, Portugal', 41.5628, -8.43, 220, 'stadium'],
    ['zs-ventas', 'Plaza de Toros de Las Ventas', 'Madrid, España', 40.4324, -3.6616, 120, 'stadium'],
    ['zs-maestranza', 'Real Maestranza', 'Sevilla, España', 37.386, -5.998, 100, 'stadium'],
    ['zs-nimes', 'Anfiteatro de Nîmes', 'Nîmes, Francia', 43.8346, 4.36, 120, 'stadium'],
    ['zs-verona', 'Arena de Verona', 'Verona, Italia', 45.439, 10.9944, 140, 'stadium'],
    ['zs-eljem', 'Anfiteatro de El Jem', 'El Jem, Túnez', 35.2964, 10.7068, 140, 'stadium'],
    ['za-opo', 'Aeropuerto de Oporto', 'Oporto, Portugal', 41.2481, -8.6814, 750, 'airport'],
    ['za-fao', 'Aeropuerto de Faro', 'Faro, Portugal', 37.0144, -7.9659, 750, 'airport'],
    ['za-mah', 'Aeropuerto de Menorca', 'Menorca, España', 39.8626, 4.2186, 750, 'airport'],
    ['za-fue', 'Aeropuerto de Fuerteventura', 'Fuerteventura, España', 28.4527, -13.8638, 750, 'airport'],
    ['za-ace', 'Aeropuerto de Lanzarote', 'Lanzarote, España', 28.9455, -13.6052, 750, 'airport'],
    ['za-vgo', 'Aeropuerto de Vigo', 'Vigo, España', 42.2318, -8.6268, 750, 'airport'],
    ['za-zaz', 'Aeropuerto de Zaragoza', 'Zaragoza, España', 41.6662, -1.0415, 750, 'airport'],
    ['za-grx', 'Aeropuerto de Granada', 'Granada, España', 37.1887, -3.7774, 750, 'airport'],
    ['za-ovd', 'Aeropuerto de Asturias', 'Asturias, España', 43.5636, -6.0346, 750, 'airport'],
    ['za-bhx', 'Aeropuerto de Birmingham', 'Birmingham, Reino Unido', 52.4539, -1.748, 750, 'airport'],
    ['za-edi', 'Aeropuerto de Edimburgo', 'Edimburgo, Reino Unido', 55.95, -3.3725, 750, 'airport'],
    ['za-gla', 'Aeropuerto de Glasgow', 'Glasgow, Reino Unido', 55.8719, -4.4331, 750, 'airport'],
    ['za-bru', 'Aeropuerto de Bruselas', 'Bruselas, Bélgica', 50.901, 4.4844, 750, 'airport'],
    ['za-dus', 'Aeropuerto de Düsseldorf', 'Düsseldorf, Alemania', 51.2895, 6.7668, 750, 'airport'],
    ['za-ber', 'Aeropuerto de Berlín-Brandeburgo', 'Berlín, Alemania', 52.3667, 13.5033, 750, 'airport'],
    ['za-ham', 'Aeropuerto de Hamburgo', 'Hamburgo, Alemania', 53.6304, 9.9882, 750, 'airport'],
    ['za-prg', 'Aeropuerto de Praga', 'Praga, Chequia', 50.1008, 14.26, 750, 'airport'],
    ['za-waw', 'Aeropuerto de Varsovia', 'Varsovia, Polonia', 52.1657, 20.9671, 750, 'airport'],
    ['za-bud', 'Aeropuerto de Budapest', 'Budapest, Hungría', 47.4369, 19.2556, 750, 'airport'],
    ['za-otp', 'Aeropuerto de Bucarest', 'Bucarest, Rumanía', 44.5711, 26.085, 750, 'airport'],
    ['za-mxp', 'Aeropuerto de Milán-Malpensa', 'Milán, Italia', 45.6306, 8.7281, 750, 'airport'],
    ['za-vce', 'Aeropuerto de Venecia', 'Venecia, Italia', 45.5053, 12.3519, 750, 'airport'],
    ['za-nap', 'Aeropuerto de Nápoles', 'Nápoles, Italia', 40.886, 14.2908, 750, 'airport'],
    ['za-nce', 'Aeropuerto de Niza', 'Niza, Francia', 43.6584, 7.2159, 750, 'airport'],
    ['za-lys', 'Aeropuerto de Lyon', 'Lyon, Francia', 45.7256, 5.0811, 750, 'airport'],
    ['za-kef', 'Aeropuerto de Keflavík', 'Reikiavik, Islandia', 63.985, -22.6056, 750, 'airport'],
    ['za-tlv', 'Aeropuerto Ben Gurión', 'Tel Aviv, Israel', 32.0114, 34.8867, 750, 'airport'],
    ['za-ruh', 'Aeropuerto de Riad', 'Riad, Arabia Saudí', 24.9578, 46.6989, 750, 'airport'],
    ['za-jed', 'Aeropuerto de Yeda', 'Yeda, Arabia Saudí', 21.6796, 39.1565, 750, 'airport'],
    ['za-bom', 'Aeropuerto de Bombay', 'Bombay, India', 19.0896, 72.8656, 750, 'airport'],
    ['za-blr', 'Aeropuerto de Bangalore', 'Bangalore, India', 13.1986, 77.7066, 750, 'airport'],
    ['za-tpe', 'Aeropuerto de Taoyuan', 'Taipéi, Taiwán', 25.0777, 121.2328, 750, 'airport'],
    ['za-pvg', 'Aeropuerto de Shanghái-Pudong', 'Shanghái, China', 31.1443, 121.8083, 750, 'airport'],
    ['za-can', 'Aeropuerto de Cantón', 'Cantón, China', 23.3924, 113.2988, 750, 'airport'],
    ['za-kix', 'Aeropuerto de Kansai', 'Osaka, Japón', 34.432, 135.2304, 750, 'airport'],
    ['za-mnl', 'Aeropuerto de Manila', 'Manila, Filipinas', 14.5086, 121.0194, 750, 'airport'],
    ['za-cgk', 'Aeropuerto de Yakarta', 'Yakarta, Indonesia', -6.1256, 106.6559, 750, 'airport'],
    ['za-han', 'Aeropuerto de Hanói', 'Hanói, Vietnam', 21.2212, 105.8072, 750, 'airport'],
    ['za-per', 'Aeropuerto de Perth', 'Perth, Australia', -31.9385, 115.9672, 750, 'airport'],
    ['za-mel', 'Aeropuerto de Melbourne', 'Melbourne, Australia', -37.669, 144.841, 750, 'airport'],
    ['za-bne', 'Aeropuerto de Brisbane', 'Brisbane, Australia', -27.3942, 153.1218, 750, 'airport'],
    ['za-hnl', 'Aeropuerto de Honolulu', 'Honolulu, EE. UU.', 21.3187, -157.9224, 750, 'airport'],
    ['za-sea', 'Aeropuerto de Seattle-Tacoma', 'Seattle, EE. UU.', 47.4502, -122.3088, 750, 'airport'],
    ['za-bos', 'Aeropuerto Logan', 'Boston, EE. UU.', 42.3656, -71.0096, 750, 'airport'],
    ['za-las', 'Aeropuerto de Las Vegas', 'Las Vegas, EE. UU.', 36.084, -115.1537, 750, 'airport'],
    ['za-phx', 'Aeropuerto de Phoenix', 'Phoenix, EE. UU.', 33.4342, -112.0116, 750, 'airport'],
    ['za-iah', 'Aeropuerto de Houston', 'Houston, EE. UU.', 29.9902, -95.3368, 750, 'airport'],
    ['za-iad', 'Aeropuerto de Dulles', 'Washington D. C., EE. UU.', 38.9531, -77.4565, 750, 'airport'],
    ['za-yul', 'Aeropuerto de Montreal', 'Montreal, Canadá', 45.4706, -73.7408, 750, 'airport'],
    ['za-yvr', 'Aeropuerto de Vancouver', 'Vancouver, Canadá', 49.1967, -123.1815, 750, 'airport'],
    ['za-cun', 'Aeropuerto de Cancún', 'Cancún, México', 21.0365, -86.8771, 750, 'airport'],
    ['za-hav', 'Aeropuerto de La Habana', 'La Habana, Cuba', 22.9892, -82.4091, 750, 'airport'],
    ['za-pty', 'Aeropuerto de Tocumen', 'Panamá', 9.0714, -79.3835, 750, 'airport'],
    ['za-uio', 'Aeropuerto de Quito', 'Quito, Ecuador', -0.1292, -78.3575, 750, 'airport'],
    ['za-mvd', 'Aeropuerto de Carrasco', 'Montevideo, Uruguay', -34.8384, -56.0308, 750, 'airport'],
    ['za-gig', 'Aeropuerto de Galeão', 'Río de Janeiro, Brasil', -22.8089, -43.2436, 750, 'airport'],
    ['za-cpt', 'Aeropuerto de Ciudad del Cabo', 'Ciudad del Cabo, Sudáfrica', -33.9715, 18.6021, 750, 'airport'],
    ['za-alg', 'Aeropuerto de Argel', 'Argel, Argelia', 36.691, 3.2154, 750, 'airport'],
    ['za-acc', 'Aeropuerto de Accra', 'Accra, Ghana', 5.6052, -0.1668, 750, 'airport'],
    ['zp-dunkerque', 'Puerto de Dunkerque', 'Dunkerque, Francia', 51.03, 2.37, 320, 'port'],
    ['zp-zeebrugge', 'Puerto de Zeebrugge', 'Brujas, Bélgica', 51.33, 3.2, 320, 'port'],
    ['zp-trieste', 'Puerto de Trieste', 'Trieste, Italia', 45.64, 13.76, 320, 'port'],
    ['zp-livorno', 'Puerto de Livorno', 'Livorno, Italia', 43.55, 10.3, 320, 'port'],
    ['zp-napoles', 'Puerto de Nápoles', 'Nápoles, Italia', 40.84, 14.27, 320, 'port'],
    ['zp-laspezia', 'Puerto de La Spezia', 'La Spezia, Italia', 44.1, 9.83, 320, 'port'],
    ['zp-lisboa', 'Puerto de Lisboa', 'Lisboa, Portugal', 38.7, -9.15, 320, 'port'],
    ['zp-sines', 'Puerto de Sines', 'Sines, Portugal', 37.95, -8.88, 320, 'port'],
    ['zp-tallin', 'Puerto de Tallin', 'Tallin, Estonia', 59.45, 24.76, 320, 'port'],
    ['zp-spb', 'Puerto de San Petersburgo', 'San Petersburgo, Rusia', 59.9, 30.22, 320, 'port'],
    ['zp-vladi', 'Puerto de Vladivostok', 'Vladivostok, Rusia', 43.11, 131.88, 320, 'port'],
    ['zp-halifax', 'Puerto de Halifax', 'Halifax, Canadá', 44.64, -63.56, 320, 'port'],
    ['zp-nola', 'Puerto de Nueva Orleans', 'Nueva Orleans, EE. UU.', 29.92, -90.05, 320, 'port'],
    ['zp-baltimore', 'Puerto de Baltimore', 'Baltimore, EE. UU.', 39.26, -76.57, 320, 'port'],
    ['zp-oakland', 'Puerto de Oakland', 'Oakland, EE. UU.', 37.8, -122.32, 320, 'port'],
    ['zp-tacoma', 'Puerto de Tacoma', 'Tacoma, EE. UU.', 47.27, -122.4, 320, 'port'],
    ['zp-kingston', 'Puerto de Kingston', 'Kingston, Jamaica', 17.97, -76.8, 320, 'port'],
    ['zp-colon', 'Puerto de Colón', 'Colón, Panamá', 9.35, -79.9, 320, 'port'],
    ['zp-paranagua', 'Puerto de Paranaguá', 'Paranaguá, Brasil', -25.5, -48.52, 320, 'port'],
    ['zp-guayaquil', 'Puerto de Guayaquil', 'Guayaquil, Ecuador', -2.28, -79.9, 320, 'port'],
    ['zp-lazaro', 'Puerto Lázaro Cárdenas', 'Michoacán, México', 17.95, -102.17, 320, 'port'],
    ['zp-jeddah', 'Puerto Islámico de Yeda', 'Yeda, Arabia Saudí', 21.48, 39.17, 320, 'port'],
    ['zp-salalah', 'Puerto de Salalah', 'Salalah, Omán', 16.95, 54.0, 320, 'port'],
    ['zp-bandar', 'Puerto de Bandar Abbas', 'Bandar Abbas, Irán', 27.13, 56.27, 320, 'port'],
    ['zp-catlai', 'Puerto de Cat Lai', 'Ciudad Ho Chi Minh, Vietnam', 10.77, 106.79, 320, 'port'],
    ['zp-manila', 'Puerto de Manila', 'Manila, Filipinas', 14.59, 120.95, 320, 'port'],
    ['zp-dalian', 'Puerto de Dalian', 'Dalian, China', 38.93, 121.65, 320, 'port'],
    ['zp-xiamen', 'Puerto de Xiamen', 'Xiamen, China', 24.45, 118.07, 320, 'port'],
    ['zp-brisbane', 'Puerto de Brisbane', 'Brisbane, Australia', -27.38, 153.17, 320, 'port'],
    ['zp-abiyan', 'Puerto de Abiyán', 'Abiyán, Costa de Marfil', 5.29, -4.01, 320, 'port'],
    ['zp-tema', 'Puerto de Tema', 'Tema, Ghana', 5.63, 0.01, 320, 'port'],
    ['zp-dakar', 'Puerto de Dakar', 'Dakar, Senegal', 14.68, -17.43, 320, 'port'],
    ['zp-luanda', 'Puerto de Luanda', 'Luanda, Angola', -8.8, 13.23, 320, 'port'],
    ['zo-stonehenge', 'Stonehenge', 'Wiltshire, Reino Unido', 51.1789, -1.8262, 40, 'obelisk'],
    ['zo-cristorey', 'Santuario de Cristo Rey', 'Almada, Portugal', 38.678, -9.1717, 50, 'obelisk'],
    ['zo-foro', 'Foro Romano', 'Roma, Italia', 41.8925, 12.4853, 160, 'castle'],
    ['zo-pompeya', 'Pompeya', 'Nápoles, Italia', 40.7506, 14.4869, 200, 'castle'],
    ['zo-delfos', 'Delfos', 'Grecia', 38.4824, 22.501, 120, 'castle'],
    ['zo-efeso', 'Éfeso', 'Selçuk, Turquía', 37.939, 27.341, 140, 'castle'],
    ['zo-persepolis', 'Persépolis', 'Irán', 29.9355, 52.8916, 180, 'castle'],
    ['zo-tikal', 'Tikal', 'Petén, Guatemala', 17.222, -89.6237, 130, 'pyramid'],
    ['zo-palenque', 'Palenque', 'Chiapas, México', 17.4838, -92.046, 130, 'pyramid'],
    ['zo-sacsay', 'Sacsayhuamán', 'Cusco, Perú', -13.5086, -71.9818, 160, 'castle'],
    ['zo-zimbabue', 'Gran Zimbabue', 'Zimbabue', -20.2674, 30.9338, 140, 'castle'],
    ['zo-lalibela', 'Iglesias de Lalibela', 'Lalibela, Etiopía', 12.0319, 39.0475, 70, 'church'],
    ['zo-terracota', 'Ejército de Terracota', 'Xi\'an, China', 34.3849, 109.2785, 140, 'castle'],
    ['zo-fatima', 'Santuario de Fátima', 'Fátima, Portugal', 39.6322, -8.6732, 90, 'church'],
    ['zo-lourdes', 'Santuario de Lourdes', 'Lourdes, Francia', 43.0975, -0.0583, 90, 'church'],
    ['zo-hassan', 'Mezquita Hassan II', 'Casablanca, Marruecos', 33.6086, -7.6326, 110, 'dome'],
    ['zo-pilar', 'Basílica del Pilar', 'Zaragoza, España', 41.6564, -0.8786, 90, 'church'],
    ['zo-salamanca', 'Catedral de Salamanca', 'Salamanca, España', 40.9609, -5.6667, 90, 'church'],
    ['zo-leon', 'Catedral de León', 'León, España', 42.5994, -5.5672, 90, 'church'],
    ['zo-valencia', 'Catedral de Valencia', 'Valencia, España', 39.4753, -0.3753, 80, 'church'],
    ['zo-palma', 'La Seu', 'Palma, España', 39.5675, 2.6489, 100, 'church'],
    ['zo-batllo', 'Casa Batlló', 'Barcelona, España', 41.3917, 2.1649, 40, 'castle'],
    ['zo-pedrera', 'La Pedrera', 'Barcelona, España', 41.3953, 2.1618, 60, 'castle'],
    ['zo-guell', 'Parque Güell', 'Barcelona, España', 41.4145, 2.1527, 120, 'castle'],
    ['zo-cibeles', 'Palacio de Cibeles', 'Madrid, España', 40.4192, -3.6931, 100, 'castle'],
    ['zo-prado', 'Museo del Prado', 'Madrid, España', 40.4138, -3.6921, 130, 'castle'],
    ['zo-debod', 'Templo de Debod', 'Madrid, España', 40.424, -3.7178, 50, 'castle'],
    ['zo-plazaespana', 'Plaza de España', 'Sevilla, España', 37.3772, -5.9869, 160, 'dome'],
    ['zo-montecassino', 'Abadía de Montecassino', 'Cassino, Italia', 41.49, 13.814, 140, 'castle']
  ];

  // ---------- Dibujo en el mapa ----------
  // Los monumentos se pintan DENTRO del mapa (capas de símbolos de MapLibre), no como elementos HTML encima: así van
  // pegados al mapa en cada fotograma (sin desfases ni parpadeos al mover o hacer zoom) y nunca los oculta el colocador de etiquetas.
  const gl = map.gl, SRC = 'monumentos-src', IMG_W = 384, ZMIN = MIN_Z - 1;          // ZMIN en zoom de MapLibre (= zoom del juego - 1)
  const pxm = (z, lat) => Math.pow(2, z + 1) * 256 / (40075016.686 * Math.max(0.05, Math.cos(lat * Math.PI / 180)));   // px por metro
  let uid = 0;
  const svg = (m, W, H, px) => `<svg viewBox="0 0 ${W} ${H}" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMax meet"${px ? ` width="${px[0]}" height="${px[1]}"` : ''}>` +
    `<ellipse cx="${W / 2}" cy="${H - 2.5}" rx="${f(W * .46)}" ry="3.2" fill="#000" opacity=".16"/>${ART[m](('mn' + (uid++)))}</svg>`;
  const GEN = { stadium: [100, 70], airport: [100, 70], tower: [100, 100], dome: [100, 100], obelisk: [100, 100], castle: [100, 100], pyramid: [100, 100], port: [100, 70], church: [100, 100], lighthouse: [100, 100], bridge: [100, 70], mountain: [100, 100], pagoda: [100, 100] };
  const items = LIST.map(([id, name, place, lat, lng, w, vb]) => { const g = typeof vb === 'string'; return { id, name, place, lat, lng, w, art: g ? vb : id, vb: g ? GEN[vb] : vb }; });

  const raster = (str, w, h) => new Promise(res => {
    const im = new Image();
    im.onload = () => { try { const c = document.createElement('canvas'); c.width = w; c.height = h; const x = c.getContext('2d'); x.drawImage(im, 0, 0, w, h); res(x.getImageData(0, 0, w, h)); } catch (e) { res(null); } };
    im.onerror = () => res(null);
    im.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(str);
  });
  function labelImage(text) {
    const c = document.createElement('canvas'), x = c.getContext('2d'), fs = 22, pad = 14;
    x.font = '700 ' + fs + 'px system-ui, sans-serif';
    const w = Math.ceil(x.measureText(text).width) + pad * 2, h = fs + 12;
    c.width = w; c.height = h; x.font = '700 ' + fs + 'px system-ui, sans-serif';
    x.fillStyle = 'rgba(30,40,60,.78)'; x.beginPath();
    if (x.roundRect) x.roundRect(0, 0, w, h, h / 2); else x.rect(0, 0, w, h);
    x.fill(); x.fillStyle = '#fff'; x.textBaseline = 'middle'; x.fillText(text, pad, h / 2 + 1);
    return x.getImageData(0, 0, w, h);
  }
  const gids = [];   // capas de iconos (una por tipo+tamaño+franja de latitud, no una por monumento)
  const ids = () => gids;
  const setVis = () => gids.concat(['mnl']).forEach(l => { try { if (gl.getLayer(l)) gl.setLayoutProperty(l, 'visibility', on ? 'visible' : 'none'); } catch (e) {} });

  let built = false;
  async function build() {
    if (built) return; built = true;
    const arts = []; items.forEach(M => { if (!arts.find(a => a.art === M.art)) arts.push(M); });   // un dibujo por tipo, compartido
    const imgs = await Promise.all(arts.map(M => { const h = Math.round(IMG_W * M.vb[1] / M.vb[0]); return raster(svg(M.art, M.vb[0], M.vb[1], [IMG_W, h]), IMG_W, h); }));
    const okArt = {};
    arts.forEach((M, i) => { if (imgs[i]) { gl.addImage('mn-' + M.art, imgs[i], { pixelRatio: 1 }); okArt[M.art] = 1; } });
    items.forEach(M => { M.ok = !!okArt[M.art]; });
    const byId = {}; items.forEach(M => { byId[M.id] = M; });
    gl.on('styleimagemissing', e => { const M = e.id && e.id.indexOf('mnl-') === 0 && byId[e.id.slice(4)]; if (M && !gl.hasImage(e.id)) { try { gl.addImage(e.id, labelImage(M.name), { pixelRatio: 2 }); } catch (err) {} } });
    gl.addSource(SRC, { type: 'geojson', data: { type: 'FeatureCollection', features: items.map(M => ({ type: 'Feature', properties: { id: M.id }, geometry: { type: 'Point', coordinates: [M.lng, M.lat] } })) } });
    const vis = on ? 'visible' : 'none', stay = { 'icon-allow-overlap': true, 'icon-ignore-placement': true, 'icon-pitch-alignment': 'viewport', visibility: vis };
    const groups = {};
    items.forEach(M => { if (M.ok) (groups[M.art + '|' + M.w + '|' + Math.round(M.lat / 10)] = groups[M.art + '|' + M.w + '|' + Math.round(M.lat / 10)] || []).push(M); });
    Object.keys(groups).forEach((k, gi) => {
      const g = groups[k], M = g[0], minW = MIN_H * M.vb[0] / M.vb[1], stops = [];
      for (let z = ZMIN; z <= 20; z++) stops.push(z, Math.min(MAX_W, Math.max(M.w * pxm(z, M.lat), minW)) / IMG_W);
      const id = 'mn-g' + gi; gids.push(id);
      gl.addLayer({ id, type: 'symbol', source: SRC, minzoom: ZMIN, filter: ['match', ['get', 'id'], g.map(m => m.id), true, false],
        layout: { ...stay, 'icon-image': 'mn-' + M.art, 'icon-anchor': 'bottom', 'icon-size': ['interpolate', ['exponential', 2], ['zoom'], ...stops] } });
    });
    gl.addLayer({ id: 'mnl', type: 'symbol', source: SRC, minzoom: LABEL_Z - 1,
      layout: { ...stay, 'icon-image': ['concat', 'mnl-', ['get', 'id']], 'icon-anchor': 'top', 'icon-offset': [0, 3], 'icon-size': 1 } });
  }
  const start = () => { build().catch(e => { built = false; console.warn('monumentos:', e); }); };
  if (gl.isStyleLoaded && gl.isStyleLoaded()) start(); else gl.once('load', start);

  // ---------- Ficha al tocar un monumento ----------
  const css = document.createElement('style');
  css.textContent = `#mn-card { position: fixed; left: 50%; bottom: 86px; transform: translateX(-50%); z-index: 900; background: #fff; color: #1d2433; border-radius: 14px; padding: 10px 14px 10px 12px;
      box-shadow: 0 4px 18px rgba(0,0,0,.3); display: none; align-items: center; gap: 10px; max-width: 88vw; font: 14px/1.3 system-ui, sans-serif; }
    #mn-card.show { display: flex; }
    #mn-card b { display: block; font-size: 15px; } #mn-card small { color: #667; }
    #mn-card button { border: 0; background: #eef0f4; border-radius: 10px; padding: 6px 10px; font: inherit; cursor: pointer; }`;
  document.head.appendChild(css);
  const card = document.createElement('div'); card.id = 'mn-card'; card.setAttribute('role', 'status');
  card.innerHTML = '<span style="font-size:26px">🏛️</span><div><b></b><small></small></div><button type="button">Ir</button>';
  document.body.appendChild(card);
  let cardT = 0, cardId = null;
  const hideCard = () => card.classList.remove('show');
  function showCard(M) {
    cardId = M.id; card.querySelector('b').textContent = M.name; card.querySelector('small').textContent = M.place;
    card.classList.add('show'); clearTimeout(cardT); cardT = setTimeout(hideCard, 5000);
  }
  card.querySelector('button').addEventListener('click', () => { const M = items.find(m => m.id === cardId); if (M) map.flyTo([M.lat, M.lng], Math.max(map.getZoom(), 17)); hideCard(); });
  gl.on('click', e => {
    if (!on || !built) return;
    try {
      const hit = gl.queryRenderedFeatures(e.point, { layers: ids().filter(l => gl.getLayer(l)) });
      const M = hit.length && items.find(m => m.id === hit[0].properties.id);
      if (M) showCard(M);
    } catch (err) {}
  });

  function apply() {
    if (btn) { btn.setAttribute('aria-pressed', on ? 'true' : 'false'); btn.style.opacity = on ? '1' : '.55'; btn.title = on ? 'Monumentos: visibles' : 'Monumentos: ocultos'; btn.dataset.label = 'Monumentos: ' + (on ? 'sí' : 'no'); }
    setVis(); if (!on) hideCard();
  }
  if (btn) btn.addEventListener('click', () => {
    on = !on;
    try { localStorage.setItem(KEY, on ? '1' : '0'); } catch (e) {}
    apply();
  });
  apply();

  // Consola: Monumentos.list() y Monumentos.goto('sagrada')
  window.Monumentos = {
    list: () => items.map(({ id, name, place, lat, lng }) => ({ id, name, place, lat, lng })),
    goto: id => { const M = items.find(m => m.id === id); if (!M) return 'No existe ese monumento'; map.flyTo([M.lat, M.lng], 17); return M.name; },
    _svg: (id, W, H) => svg(id, W, H)
  };
})();
